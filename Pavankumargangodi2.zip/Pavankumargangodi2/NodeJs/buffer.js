var b=Buffer.alloc(10);
//var buff=Buffer.from("Sample data");
//console.log(buff.toString());



var noOfBytesWritten=b.write("This is my sample");
console.log("Bytes written:"+noOfBytesWritten)
console.log(b.toString());
