
var mod1obj=require('./lib/mod1');
var mod2obj=require('./lib/mod2');

//calling files data using object
console.log(mod1obj);
console.log(mod1obj.id);

//console.log('get doget');

console.log(mod1obj.doGet);
console.log(mod2obj.id);