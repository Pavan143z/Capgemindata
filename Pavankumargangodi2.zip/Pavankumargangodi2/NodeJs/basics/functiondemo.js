function helloword(name)
{
    console.log("Welcome to" +name);
}
//call the hello world function
helloword('Hello World')