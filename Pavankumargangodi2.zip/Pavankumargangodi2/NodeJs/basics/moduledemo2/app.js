var obj=require('./mod1')

console.log(obj.hello.getData);

(obj.hello.getLogin());