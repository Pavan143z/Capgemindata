// var hello={
//     getData:function(){
//         console.log("In getData");
//     },
//     getLogin :function(){
//         console.log("In GetLogin");
//     }
//     };
//     module.exports=hello;
module.exports.hello={
    getData:"hello",
    getLogin:function(){
        console.log("in login function");
        //return a
    }
}