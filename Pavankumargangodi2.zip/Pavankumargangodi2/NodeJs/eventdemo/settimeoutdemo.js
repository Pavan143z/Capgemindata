setTimeout(function(str1,str2){
    console.log(str1+" "+str2);
},10000,'hello.',"How are you ?");

