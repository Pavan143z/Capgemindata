const express=require('express');
var app=express();

//defini some array object
const courses=[{"id":1,"name":"rashmi"},
{"id":2,"name":"anushka"}];
//root path url
app.get('/',function(req,res){
    res.send('You are in Root page');

});
//home page url
app.get('/home',function(req,res){
    res.send('You are in home page');
    
});
//get all courses
app.get('/courses',function(req,res){
    res.send(courses);
    
});

//get only one course based on id
app.get('/courses/:id',function(req,res){
    const couse=courses.find(c=>c.id===parseInt(req.params.id))
    if(!couse)
    res.send('course with given is does not exists');
    res.send(couse);
});


//post 

//defining the port dynamically
const port=process.env.PORT || 2000;
app.listen(port,function(){
    console.log(`server is listening to port ${port}`)
});