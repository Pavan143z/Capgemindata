var express = require("express");
var cors = require('cors');
var mongoose = require("mongoose");
var app = express();
const route = require("./router/route");
app.use(express.json())
mongoose.connect("mongodb://localhost:27017/mycgmean", { useNewUrlParser: true });
mongoose.connection.on("connected", () => {
  console.log("mongodb connected on port number 27017");
});


app.get("/", (req, res) => {
  res.send("Hello from Root path");
});

app.use(cors());
app.use("/api", route);
const port = 5000;
app.listen(port, function() {
  console.log("server started on port number " + port);
});



// var express = require('express');

// var mongoose = require('mongoose');

// var 
// bodyparser = require('body-parser');

// var 
// cors = require('cors');

// const 
// route = require('./route/routes');

// var 
// app = express();

// //connect to mangodb

// mongoose.connect('mongodb://localhost:27017/shoppinglistsyntel', {useNewUrlParser:
// true});

// //on connetion

// mongoose.connection.on('connected', ()
// => {

// console.log('Mongodb connected at post 27017');



// });

// mongoose.connection.on('error', (err)
// => {

// console.log(err);

// });



// //adding middle ware -cors

// app.use(cors());

// app.use(bodyparser.json());

// app.use('/api',
// route);



// const PORT=4000
// app.listen(PORT,function () {console.log("Server Started….." +PORT);
// })



