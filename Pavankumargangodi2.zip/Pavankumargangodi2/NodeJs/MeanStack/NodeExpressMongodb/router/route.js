var express = require("express");
var router = express.Router();
const item = require("../model/items");
router.get("/", (req, res) => {
  console.log("I am from different module");
});
//geting
router.get("/items", (req, res) => {
    item.find({}, (err, item) => {
      if (err) {
        res.json(err);
      } else {
        res.json(item);
      }
    });
  });
router.post("/items", (req, res, next) => {
  const newitem = new item({
    itemname: req.body.itemname,
    itemquantity: req.body.itemquantity,
    itembought: req.body.itembought
  });
  newitem.save((err, item) => {
    if (err) {
      res.json(err);  
    } else {
      res.json(item);
    }
  });
});
//delete 
router.delete("/items/:id", (req, res) => {
  item.remove({ _id: req.params.id }, (err, items) => {
    if (err) {
      res.json(err);
    } else {
      res.json(items);
    }
  });
});
module.exports = router;