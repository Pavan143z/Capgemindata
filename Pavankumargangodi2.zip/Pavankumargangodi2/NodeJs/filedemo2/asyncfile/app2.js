const fs = require('fs');
//write in file
let student = [{
name: 'rashmi ',
age: 25,
gender: 'female'
}]
let data = JSON.stringify(student);
fs.writeFile('student1.json',data, (err)=> {
if (err)
throw err;
else

console.log('data write into the file')

});




//append


let student1= {
name: 'ali raj',
age: 9,
gender: 'male'
}
console.log('this is the end of the program')
//append
fs.readFile('student.json', (err,data) => {
if (err)
throw err;
else {
let read;
read = JSON.parse(data);
read.push(student1);
read = JSON.stringify(read);
fs.writeFile('student1.json',read, (err)=> {
if (err)
throw err;
else 
console.log('data appended into the file');

});
}
})