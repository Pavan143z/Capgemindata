const fs = require('fs');
let student = {
    name: 'pavan',
    age: 23,
    gender: 'male'
}


let data = JSON.stringify(student);
fs.writeFile('student.json', data, (err) =>{


if (err)
    throw err;
    else
    console.log('data written into the file');
    
}
);
console.log('data written into the file')