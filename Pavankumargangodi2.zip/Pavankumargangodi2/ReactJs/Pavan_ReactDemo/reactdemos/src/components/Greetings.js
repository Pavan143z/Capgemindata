import React from 'react';

const Greetings =(props)=>{
    return <h1>Hello {props.name}</h1>
}
export default Greetings;