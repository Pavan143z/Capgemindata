// import React, { Component } from 'react'

// class ShowContact extends Component {
//     constructor(props) {
//         super(props)

//     }
//     render() {
//         const contact = this.props.contacts;
//         // console.log(contact)

//         return (
//             <div>
//                 <table className="table table-bordered">
//                     <thead>
//                         <tr>
//                             <th>Contact Name</th>
//                             <th>Contact Number</th>
//                         </tr>
//                     </thead>
//                     <tbody>
//                         {this.props.contacts.map((contact) =>
//                             <tr key={contact.id}>
//                                 <td>{contact.contactname}</td>
//                                 <td>{contact.contactnumber}</td>
//                             </tr>
//                         )}
//                     </tbody>
//                 </table>

//             </div>


//         )
//     }


// }
// export default ShowContact;




import React from 'react'
import ViewContact from './View Contacts';
class ShowContact extends React.Component {
    render() {
        return (
            <table className="table table-bordered">
                <thead>
                    <tr><th>Contact Name</th>
                        <th>Contact Number</th>
                    </tr>
                </thead>
                <tbody>
                    {this.props.contacts.map((contact) =>
                        <tr key={contact.id}>
                            <td>{contact.contactname}</td>
                            <td>{contact.contactnumber}</td>
                            <td>
                                <button onClick={() => this.props.deleteContact(contact.id)}
                                    className="btn btn-danger">X</button>
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        )
    }
}
export default ShowContact;