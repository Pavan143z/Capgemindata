// import React, { Component } from 'react'
// import AddContact from './AddContact';
// import ShowContact from './ShowContact';
// import axios from 'axios'
// class ViewContact extends Component {

//     state = { contacts: [] }
//      baseURL = "http://localhost:3000/contacts";

//     componentDidMount() {
//         console.log(this.state.contacts);
//     }
//     getcontacts = () => {

//         axios.get(this.baseURL).then((response) => {
//             this.setState({ contacts: response.data })
//         });

//     }

// addContact =(contact)=>{
//     axios.post(this.baseURL,contact).then((response)=>{
//         this.getcontacts();
//         alert('Contact Added');
//     })
// }
//     render() {

//         return (
//             <div>
//                 <h1 className="page-header">Manage Contacts</h1>
//                 <AddContact addContact={(contact)=>this.addContact(contact)} />
//                 <ShowContact contacts={this.state.contacts} />

//             </div>

//         )
//     }


// }
// export default ViewContact;





import React, { Component } from 'react'
import { Link, Redirect } from 'react-router-dom';
import axios from 'axios';
import { withRouter } from 'react-router-dom'
import AddContact from './AddContact';
import ShowContact from './ShowContact';
// const Product = () => {
// return ( 
// <div className="well">
// <Link to='/products/1'>IPhone</Link> 
// </div>
// );
// }
class ViewContact extends Component {
    state = { contacts: [] }
    serviceUrl = "http://localhost:3000/contacts/";
    // Lifecycle hooks
    componentDidMount() { this.getContacts(); }
    getContacts = () => {
        axios.get(this.serviceUrl).then((response) => {
            this.setState({ contacts: response.data })
        })
    }
    addContact = (contact) => {
        axios.post(this.serviceUrl, contact).
            then((response) => {
                this.getContacts();
                alert('Contact Added');
            })
    }

    deleteContact =(id)=>{
        alert('contact id:'+id)
        axios.delete(this.serviceUrl+id).then((res)=>{
            this.getContacts();
        },(err)=>{
            this.setState({errors:err})
        })
        
    }
    render() {
        return (
            <div><h1 className="page-header">
                Manage Contacts </h1>
                <AddContact addContact={(contact) => this.addContact(contact)} />
                <ShowContact contacts={this.state.contacts} deleteContact={this.deleteContact} />
            </div>
        );
    }
}
 export default ViewContact;
