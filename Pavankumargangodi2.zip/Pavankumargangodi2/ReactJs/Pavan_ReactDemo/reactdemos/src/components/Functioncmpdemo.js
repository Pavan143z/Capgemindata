import React from 'react'


const Functioncmpdemo=()=>{
    return <h1>This is my functional component</h1>
}
export default Functioncmpdemo ;