import React from 'react'
export class Home extends React.Component {
    constructor() {
        super();
        this.state = { display: false }
    }
    display() {
        this.setState({ display: !this.state.display })
    }
    render() {
        return (
            <div>
                <h1>Home Component</h1>
                {
                    this.state.display ? <img src={require('./maxresdefault.jpg')} /> : null
                }
                <button onClick={() => this.display()}>Click</button>
            </div>
        )
    }

}
export default Home;

