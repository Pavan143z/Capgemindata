// import React,{Component } from 'react'

// class AddContact extends Component {
//     //step 1
//     constname=React.createRef();
//     constnumber=React.createRef();

//     handleAddContact=()=>{
//         let constObject={contactname:this.contactname.current.value,
//             contactnumber:this.contactnumber.current.value}
//         this.props.addContact(constObject)
//     }
//     render(){

//         return (
//             <div className="well">
//             <form>
//                 {/* attach the ref variables to your input */}
//               &nbsp;&nbsp;&nbsp;  Contact Name<input ref={this.contactname}/>
//                 <br/>
//                 Contact Number <input ref={this.contactnumber}/>
//                 <br/>
//                 <button onClick={this.handleAddContact} className="btn btn-success">Add Contact</button>



//                 </form>
//                 </div>



//     )
// }


// }
// export default AddContact;


import React, { Component } from 'react'
class AddContact extends Component {

    //step1

    //create 2 reference veriables 
    contactname = React.createRef();
    contactnumber = React.createRef();
    handleAddConatct = () => {
        let contObject = {
            contactname: this.contactname.current.value,
            contactnumber: this.contactnumber.current.value
        };
        this.props.addContact(contObject)
    }
    render() {
        return (
            <div className="well">
                <form>
                    {/* attach the ref variables to your input firlds */}
                    Contact Name <input ref={this.contactname} />
                    <br />
                    Conatct Number <input ref={this.contactnumber} />
                    <br />
                    <button onClick={this.handleAddConatct} className="btn btn-success">
                        Add New Contact</button>
                </form>
            </div>
        );
    }
}
export default AddContact;