import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import Create from './Create';
import Get from './Get';


class App extends Component {
  render() {
    return (
      <div className="container">
      <Router>
      <div className="container">
        <h1>Manage Products</h1>
        <hr/>
        <ul>
          <li><Link to={'/create'}><h2>Create Product</h2></Link></li>
          <li><Link to={'/Get'}><h2>List Products</h2></Link></li>
        </ul>
        <hr />
        <Switch>
            <Route exact path='/create' component={ Create } />
            <Route path='/Get' component={ Get } />
        </Switch>
      </div>
    </Router>
    </div>
    );
  }
}

export default App;
