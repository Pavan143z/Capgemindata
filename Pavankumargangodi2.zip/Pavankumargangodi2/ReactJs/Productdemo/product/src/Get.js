import React, { Component } from 'react';
import axios from 'axios';
//import TableRow from './TableRow';

export default class Get extends Component {

    constructor(props) {
        super(props);
        this.state = {
          serverports: []
        };
         this.deleteProd= this.deleteProd.bind(this);
        this.onChangeprodName= this.onChangeprodName.bind(this);
            this.onChangeprodPrice= this.onChangeprodPrice.bind(this);
        this.onSubmit= this.onSubmit.bind(this);
      }
      baseUrl = "http://localhost:4000/serverport";
    
      getproducts = () => {
        axios.get(this.baseUrl).then(response => {
          this.setState({ serverports: response.data });
        });
      };
    
      deleteProd(_id) {
        axios.delete("http://localhost:4000/serverport/deleteProd/" + _id).then(res => {
            this.getproducts();
          });
      }
    
     
    
       onSubmit=(e)=>{
        e.preventDefault()
        const serverports = {
          prodName: this.state.prodName,
          prodPrice: this.state.prodPrice
         
        };
        axios.put(this.baseUrl+'/edit/'+ this.state.id, serverports).then(response=>{
          this.getproducts()
      
        })
      }
      
    
      onChangeprodName(event){
        this.setState({
            prodName: event.target.value
        })
    }
    onChangeprodPrice(event){
        this.setState({
            prodPrice: event.target.value
        })
    }
    
      componentDidMount() {
        this.getproducts();
      }

    render() {
      return (
        <div className="container">
          <table border='2' className="table table-border " >
         <thead>
                <tr>
                  <td>ID</td>
                  <td>Product Name</td>
                  <td>Product Price</td>
                </tr>
         </thead>
         <tbody>
          {this.state.serverports.map(function(object, i) {
          return (
            <tr key={i}>
              <td>{object._id}</td>
              <td>{object.prodName}</td>
              <td>{object.prodPrice}</td>
              <td>
                  <button  className="btn btn-danger" onClick={(e)=> this.deleteProd(object._id)}>X
                  </button> </td>
                  
            </tr>
          );
        })}
      </tbody>
        </table>
        </div>
      );
    }
  }