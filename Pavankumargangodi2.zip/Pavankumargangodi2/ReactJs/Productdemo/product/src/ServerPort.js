const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema for ServerPort
const ServerPort = new Schema({
  prodName: {
    type: String
  },
  prodPrice: {
      type: Number
  }
},{
    collection: 'Productredux'
});

module.exports = mongoose.model('ServerPort', ServerPort);