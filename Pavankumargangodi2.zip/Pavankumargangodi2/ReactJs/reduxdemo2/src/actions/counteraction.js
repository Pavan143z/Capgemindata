const INCREMENT = 'INCREMENT';


const incrementCount = () => ({
    type: INCREMENT
})

export { INCREMENT, incrementCount};
