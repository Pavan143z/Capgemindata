import React from 'react';
import {connect} from 'react-redux';
import {incrementCount} from './actions/counteraction'
class Counter extends React.Component{
    
    render(){
        const{count,incrementCount}=this.props;
        return(
            <div>
                <h1>I am a Counter..!</h1>
                <p>Count:{count}</p>
                <button  onClick={()=>incrementCount()}>increment</button>
            </div>
        );
    }}
    const mapStateToProps=(state)=>({
        count:state
    }) ;
    const mapDispatchTOProps=(dispatch)=>({
     
        incrementCount:()=>dispatch(incrementCount())
    });
    
    
     

    export default connect(mapStateToProps,mapDispatchTOProps)(Counter) ;