import React from 'react'
import Theater from './Theater'
class Mall extends React.Component{
    render(){
        return(
            <div>
                <h1>Mall</h1>
                <Theater />
            </div>
        )
    }
}
export default Mall;