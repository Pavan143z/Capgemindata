import React from 'react'
import Screen from './Screen'
class Theater extends React.Component{
    render(){
        return(
            <div>
                <h1>Theater</h1>
                <Screen />
            </div>
        )
    }
}
export default Theater;

