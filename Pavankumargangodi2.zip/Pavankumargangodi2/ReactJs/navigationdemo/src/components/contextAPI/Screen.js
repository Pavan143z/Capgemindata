import React from 'react';
import { MallContext1 } from '.';

const MovieDisplay = (props) => {

return (
<div>
<h1>Screen Name</h1>
<ul>{props.movies.map(i => <li key={i.movie}>{i.movie}</li>)}</ul>
<h1>Screen Timings</h1>
<ul>{props.movies.map(i => <li key={i.movie}>{i.time}</li>
)
}</ul>
</div>
)
}
class Screen extends React.Component {
render() {
return (
<MallContext1.Consumer>
{(movies)=> <MovieDisplay movies={movies}
/>
}
</MallContext1.Consumer>
);
}
}
export default Screen;

