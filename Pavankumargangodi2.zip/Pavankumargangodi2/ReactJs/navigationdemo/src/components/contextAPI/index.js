import React from 'react';
import Mall from './Mall'
export const MallContext1=React.createContext();

class ContextDemo1 extends React.Component{
    render(){
        const movies=[
            {movie:'Tiger',time:'9pm'},
            {movie:'KGF2',time:'11pm'},

            {movie:'Avengers-EndGame',time:'3pm'},

        ]
        return(
            <MallContext1.Provider value={movies}>
                <Mall />

            </MallContext1.Provider>
        )
    }
}
export default ContextDemo1;