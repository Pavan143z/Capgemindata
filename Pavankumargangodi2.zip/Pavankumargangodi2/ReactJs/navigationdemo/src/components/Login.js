import React from 'react'
import SignOut from "./SignOut";
class Login extends React.Component {

    constructor() {
        super();
        this.state = {
            user: {
                userName: "",
                passWord: ""
            },

            display: false,
            view: true
        };
    }
    
  UpdateState(ctrl, value) {
    const { user } = this.state; //get current state
    user[ctrl] = value; //update the user entered data
    this.setState({ user });
  }
    handleSubmit(e) {
        e.preventDefault();
        alert('login successful')
        alert(`${this.state.user.userName}`);
        this.setState({ display: true });
        this.setState({ view: false });
    }
    render() {
        const { user } = this.state;
        return (
            <div align="center">
                {this.state.view ? (
                    <form onSubmit={e => this.handleSubmit(e)}>
                       <h1>Login Page</h1>
                       
                       <label>User Name:</label>
                            <input type="text"  value={user.userName}
                                onChange={e => this.UpdateState("userName", e.currentTarget.value)} />
                           <label>Password</label>
                            <input type="password"  value={user.passWord}
                                onChange={e => this.UpdateState("passWord", e.currentTarget.value)
                                }
                            />
                            &nbsp;&nbsp;&nbsp;&nbsp;
                    <button type="submit" className="btn btn-success">LogIn</button>&nbsp;&nbsp;&nbsp;
                    {/* <button type="clear" className="btn btn-danger" onClick="clear">Clear</button> */}
                        </form> ) : null}
        {this.state.display ? <SignOut userData={this.state.user} /> : null}
      
            </div>
                );
                }
            }
export default Login;