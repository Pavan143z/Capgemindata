import React from 'react'
import ComponentF from './ComponentF'
class ComponentE extends React.Component{
    render(){
        return(
            <div>
                <h1>Component E</h1>
                <ComponentF />
            </div>
        )
    }
}
export default ComponentE;