import React, { Component } from 'react'

export class SignOut extends Component {
  render() {
    const user =this.props.userData;
    return (
      <div>
          <form  onSubmit={e=>this.handleSubmit(e)}>
           <h3>UserName:     {user.userName}</h3>
           <button type="submit" className="btn btn-danger">SignOut</button>
      </form></div>

    )
  }
}
export default SignOut;
