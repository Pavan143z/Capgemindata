import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Route, Link, Switch } from 'react-router-dom'

import ComponentC from './components/ComponentC';
import ContextDemo1 from '../src/components/contextAPI/index';
import Login from './components/Login'
import Header from './components/Header';
import Home from './components/Home'
import SignIn from './components/SignIn'

class App extends Component {
 
  
  render() {
    return (
  
         
      // {/* <h1> connect API demo</h1>
      // <ComponentC /> */}

      // {/* <ContextDemo1 /> */}
      // {/* <Login/> */}

      <Router>

        <div>

          <Header/>
          <div className="container">

            <Switch>

              

              <Route
                exact path="/Login"
                component={Login} />
                
          </Switch>
          </div>
          </div>
          </Router>

    );
  }
}

export default App;
