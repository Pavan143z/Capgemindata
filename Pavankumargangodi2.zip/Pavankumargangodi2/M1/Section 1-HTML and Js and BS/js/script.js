function submitCustomer(frm)

{ //Checking validations for Submit

    if(frm.checkValidity()){

        var customerName=frm.txtName.value;

        var customerAddress=frm.txtAddr.value;

        var customerState=frm.drpdnState.value;

        var phone=frm.numPhone.value;

        var mail=frm.txtEmail.value;

        var wayOfContact=frm.rbtnContact.value;

        var dateOfVisit=frm.date.value;

        var incident=frm.txtAdd.value;

        displayCustDetails();

 

function displayCustDetails(){

    var custObj = window.open("", "Customer Details","width =300px,height=500px");

    var custDetails = `<html>

        <head>

            <title>Dear Customer, please confirm your Details...!</title>

        </head>

        <body>

            <h2>Dear Customer, please confirm your Details...!</h2>

            <table>

                <tr>

                    <th>Customer Name</th>

                    <td>${customerName}</td>

                </tr>

                <tr>

                    <th>Address</th>

                    <td>${customerAddress}</td>

                </tr>

                <tr>

                    <th>State</th>

                    <td>${customerState}</td>

                </tr>

                <tr>

                    <th>Phone</th>

                    <td>${phone}</td>

                </tr>

                <tr>

                    <th>E-mail</th>

                    <td>${mail}</td>

                </tr>

                <tr>

                    <th>ContactWay</th>

                    <td>${wayOfContact}</td>

                </tr>

                <tr>

                    <th>DateofVisit</th>

                    <td>${dateOfVisit}</td>

                </tr>

                <tr>

                    <th>Incident</th>

                    <td>${incident}</td>

                </tr>

            </table>

        </body>

    </html>`;

    custObj.document.write(custDetails);

}

    }

}

 