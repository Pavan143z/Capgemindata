function customerDetails(frm) {

    //This method will check the form validation

    if (frm.checkValidity()) {

        var customerName = frm.txtName.value;
        var customerMobile = frm.txtAddress.value;
        var customerState = frm.drpdnState.value;
        var phone = frm.numPhone.value;
        var mail = frm.txtEmail.value;
        var wayofContact = frm.rbtnContact.value;
        var dateOfvisit = frm.dateVisit.value;
        var incident = frm.txtIncident.value;
        displayCustDetails;

        //Session Storage is used for storing the temporary data

        sessionStorage.setItem("customerName", customerName);
        sessionStorage.setItem("customerMobile", customerMobile);
        sessionStorage.setItem("customerState", customerState);
        sessionStorage.setItem("phone", phone);
        sessionStorage.setItem("mail", mail);
        sessionStorage.setItem("wayofContact", wayofContact);
        sessionStorage.setItem("dateOfvisit", dateOfvisit);
        sessionStorage.setItem("incident", incident);

    }
}

function successRefferal() {

    var txtState;

    //Session Storage is used for getting the temporary stored data

    document.getElementById("customerName").innerHTML = sessionStorage.getItem("Name");
    document.getElementById("customerMobile").innerHTML = sessionStorage.getItem("Mobile");
    document.getElementById("customerState").innerHTML = sessionStorage.getItem("Email");
    document.getElementById("phone").innerHTML = sessionStorage.getItem("dateOfBirth");
    document.getElementById("mail").innerHTML = sessionStorage.getItem("ddlCity");
    
    document.getElementById("wayofContact").innerHTML = sessionStorage.getItem("Name");
    
    document.getElementById("dateOfvisit").innerHTML = sessionStorage.getItem("Name");
    
    document.getElementById("incident").innerHTML = sessionStorage.getItem("Name");


    if (sessionStorage.getItem("state") == 'Pune' || sessionStorage.getItem("ddlCity") == 'Mumbai') {
        txtState = 'Maharastra';
    }
    else if (sessionStorage.getItem("state") == 'Chennai') {
        txtState = 'Tamil Nadu';
    }
    else {
        txtState = 'Karnataka';
    }

    document.getElementById("txtState").innerHTML = txtState;
}

function isAuthorized(){
   
    if(sessionStorage.getItem("sessionKey")==null){
        window.location.href="EmployeeRefferalForm.html";
    }
    else{
        successRefferal();
    }
}

