// Base class
class Inventory {
    // constructor
    constructor() {
    }
    // getProductIn() function
    getProductIn() { 
        return  "getUserIn() function called ..!";

    }
    // getProductOut() function
    getProductOut() {
        return "getUserOut() function called ..!";

    }
} // end of Inventory class

class Product  {
    // constructor
    constructor(prodId, prodName, prodPrice, prodDescription) {
        super();
        this._prodId_ = prodId;
        this._prodName_ = prodName;
        this._prodPrice_ = prodPrice;
        this._prodDescription_ = prodDescription;
    }
    // getProductIn() overriden function of Inventory Class
    getProductIn() {
        console.log("Product Logged In ..!");
    }
    // getProductOut() overriden function of Inventory Class
    getProductOut() {
        console.log("Product Logged Out ..!");
    }
    //  showAllProducts() function
    showAllProducts() {
        let productDetails =
            `Product Id : ${this._prodId_}
          Product Name : ${this._prodName_}
          Product Price : ${this._prodPrice_}
          Produc Description : ${this._prodDescription_}
        `;
        return productDetails;
    }
} // end of Product class

let inventoryObj = new Inventory();
let productrObj = new Product(1005, "Amit", 25, "Pune");

// By using _proto_ 
// productObj._proto_ = inventoryObj;
// console.log(productrObj._proto_.showAllProducts());

// By using Object.create() function
console.log(productObj.showAllProducts());
productObj = Object.create(inventoryObj);
console.log(productObj.getProductIn());