// Base class
class Inventory {
    // constructor
    constructor() {
    }
    // getProductIn() function
    getProductIn() {

    }
    // getProductOut() function
    getProductOut() {

    }
} // end of Inventory class

class Product extends Inventory {
    // constructor
    constructor(prodId, prodName, prodPrice, prodDescription) {
        super();
        this._prodId_ = prodId;
        this._prodName_ = prodName;
        this._prodPrice_ = prodPrice;
        this._prodDescription_ = prodDescription;
    }
    // getProductIn() overriden function of Inventory Class
    getProductIn() {
        console.log("Product Logged In ..!");
    }
    // getProductOut() overriden function of Inventory Class
    getProductOut() {
        console.log("Product Logged Out ..!");
    }
    //  showAllProducts() function
    showAllProducts() {
        let productDetails =
            `Product Id : ${this._prodId_}
          Product Name : ${this._prodName_}
          Product Price : ${this._prodPrice_}
          Produc Description : ${this._prodDescription_}
        `;
        return productDetails;
    }
} // end of Product class


// ProductUtility class for CRUD Operations
class ProductUtility {
    // addProducts() function
    constructor() {
        this._productsList_ = new Map();
        let product1 = new Product(1002, "Mobile", 19812, "Mobile");
        let product2 = new Product(1003, "Rice", 66, "Grocery");
        let  product3 = new Product(1001, "Pen", 32, "Stationary");
        let  product4 = new Product(1000, "Pencil", 8, "Stationary");

        this._productsList_.set(1, product1);
        this._productsList_.set(2, product2);
        this._productsList_.set(3, product3);
        this._productsList_.set(4, product4);
    }

    getAllProductsList() {
        return this._productsList_;
    }
    
    deleteProduct() {
        let productId = parseInt(prompt("Enter Product Id "));

        let deletedProduct
            = Array.from(this._productsList_).find
                (product => product[1]._prodId_ === productId);

        let result = false;
        if (deletedProduct !== undefined)
            result = this._productsList_.delete(deletedProduct[0]);

        return result;
    }
    showAllProductsOrderByPrice() {
        let sortedProductsList = Array.from(this._productsList_)
            .sort((a, b) => a[1]._prodPrice_ - b[1]._prodPrice_);
        return sortedProductsList;
    }
}

// Menu Driven 
console.log("Menu: ");
console.log("\t1: Add Products ");
console.log("\t2: Show All Products ");
console.log("\t3: Show All Products Order By Price");
console.log("\t4: Delete Product");
console.log("\t0: Exit");

let utilityObj;
let choiceYN = 'N';

do {
    let choice = parseInt(prompt("Enter Your Choice"));

    switch (choice) {
        // Add Product
        case 1: {
            utilityObj = new ProductUtility();
            console.log('\n\n\tAll Products are Added ');
        } break;

        // Show All Products
        case 2: {
            var productsList = utilityObj.getAllProductsList();
            console.log("\n\n\tBelow Given is the List of products ..!");
            // Reading From an Map -> READ
            for (var [k,v] of productsList) {
                console.log(productsList.get(k).showAllProducts());
            }
        } break;

        // Show All Products Order By Price
        case 3: {
            console.log("\n\n\tAfter sorting in ascending order");
            let sortedProductsList = utilityObj.showAllProductsOrderByPrice();
            for (var [k,v] of sortedProductsList) {
                console.log(productsList.get(k).showAllProducts());
            }
        } break;

    
        // Delete Product
        case 4: {
            console.log("\n\n\tAfter Deleting product from the List ..!");

            if (utilityObj.deleteProduct()) {
                for (var [k,v] of productsList) {
                    console.log(productsList.get(k).showAllProducts());
                }
            }
            else {
                console.log("\n\n\tProduct Does Not Exist ..!");
            }
        } break;

        default: {
            console.log("\n\n\tInvalid Choice ..! ");
        }
            break;
        case 0: {
            console.log("\n\n\tThank you ..! ");
            break;
        }
    }

    choiceYN = prompt("Do you wants to continue ?");
} while (choiceYN === 'Y' || choiceYN === 'y');