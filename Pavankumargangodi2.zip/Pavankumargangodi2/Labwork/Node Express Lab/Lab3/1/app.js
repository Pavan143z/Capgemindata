//declarations
var express = require('express')

var app= new express()
var cors=require('cors')
const route=require('./router/router')
const bodyParser=require('body-parser')


// funcs()
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(express.json())
app.use(cors())
app.get('/',(req,res)=>{
    res.send('hello from root path')
})
app.use('/api',route)
const port=2000
app.listen(port,function(){
    console.log('server running in 2000 port')
})