var mongodb = require('mongodb');

var mongoclient1 = mongodb.MongoClient;

var url = 'mongodb://localhost:27017/employee';

//connect to mongoclient
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err)
    }
    else {
        console.log('connection established' + url);

        //creating database
        var db = client.db('employee');

        //creating collection
        var collection = db.collection('employeescol');

        collection.update({ 'empId': 1006 }, { $set:  {"empAddress.city":"San New"} } , function (err, res) {
            if (err) {
                console.log(err);
            }
            else {
                console.log('Updated Data' + res);
            }

        });
    }
});