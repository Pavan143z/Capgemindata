var mongodb = require('mongodb');

var mongoclient1 = mongodb.MongoClient;

var url = 'mongodb://localhost:27017/mobile';

//connect to mongoclient
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err);
    }
    else {
        console.log("connection established" + url);

        var db = client.db('mobile');

        var collection = db.collection('mobilescol');

        var mobiles = [
            {
                "mobId": 1001,
                "mobName": "iPhone",
                "mobPrice": 76661.1
            },
            {
                "mobId": 1002,
                "mobName": "MicroMax",
                "mobPrice": 126661.1
            },
            {
                "mobId": 1003,
                "mobName": "Coolpad",
                "mobPrice": 7823
            },
            {
                "mobId": 1004,
                "mobName": "HTC",
                "mobPrice": 8876
            },
            {
                "mobId": 1005,
                "mobName": "LG",
                "mobPrice": 46661.1
            }
        ]
        //displaying mobile for specified range 
        collection.find({ mobPrice: { $gte: 10000, $lte: 50000 } }).sort({ mobPrice: 1 }).toArray(function (err, resPrice) {
            if (err) {
                console.log(err);
            }
            else {
                console.log('number of ', resPrice);
            }
        });
    }
});