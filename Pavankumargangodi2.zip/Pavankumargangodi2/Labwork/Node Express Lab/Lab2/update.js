var mongodb = require('mongodb');

var mongoclient1 = mongodb.MongoClient;

var url = 'mongodb://localhost:27017/product';

//connect to mongoclient
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err)
    }
    else {
        console.log('connection established' + url);

        //creating database
        var db = client.db('product');

        //creating collection
        var collection = db.collection('productscol');

        collection.update({ 'proId': 1002 }, { $set: { 'proName': 'Redmi' } }, function (err, res) {
            if (err) {
                console.log(err);
            }
            else {
                console.log('Updated Data' + res);
            }

        });
    }
});