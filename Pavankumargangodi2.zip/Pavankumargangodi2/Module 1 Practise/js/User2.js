// Base class
class Inventory {
    // constructor
    constructor() {
    }
    // getUserIn() function
    getUserIn() {

    }
    // getUserOut() function
    getUserOut() {

    }
} // end of Inventory class

class User extends Inventory {
    // constructor
    constructor(uId, uName, uAge, uCity) {
        super();
        this._uId_ = uId;
        this._uName_ = uName;
        this._uAge_ = uAge;
        this._uCity_ = uCity;
    }
    // getUserIn() overriden function of Inventory Class
    getUserIn() {
        console.log("User Logged In ..!");
    }
    // getUserOut() overriden function of Inventory Class
    getUserOut() {
        console.log("User Logged Out ..!");
    }
    //  showAllUsers() function
    showAllUsers() {
        let userDetails =
            ` User Id : ${this._uId_}
          User Name : ${this._uName_}
          User Age : ${this._uAge_}
          User City : ${this._uCity_}
        `;
        return userDetails;
    }
} // end of User class

// UserUtility class for CRUD Operations
class UserUtility {
    // addUsers() function
    constructor() {
        this._usersList_ = new Map();
        let user1 = new User(1002, "Rahul", 19, "Mumbai");
        let user2 = new User(1003, "Ram", 66, "Pune");
        let user3 = new User(1001, "Penny", 32, "Delhi");
        let user4 = new User(1000, "Sheldon", 30, "Delhi");

        this._usersList_.set(1, user1);
        this._usersList_.set(2, user2);
        this._usersList_.set(3, user3);
        this._usersList_.set(4, user4);
    }

    getAllUsersList() {
        return this._usersList_;
    }
    updateUser() {
        let userId = parseInt(prompt("Enter User Id "));

        let updatedUser
            = Array.from(this._usersList_).find
                (user => user[1]._uId_ === userId);

        let result = false;
        if (updatedUser !== undefined) {
            let age = Number.parseInt(prompt("Enter User Age : "));
            if (age != "")
                updatedUser[1]._uAge_ = age;

            let city = prompt("Enter City : ");
            if (city != "")
                updatedUser[1]._uCity_ = city;

            result = true;
        }
        return result;
    }
    deleteUser() {
        let userId = parseInt(prompt("Enter User Id "));

        let deletedUser
            = Array.from(this._usersList_).find
                (user => user[1]._uId_ === userId);

        let result = false;
        if (deletedUser !== undefined)
            result = this._usersList_.delete(deletedUser[0]);

        return result;
    }
    showAllUsersOrderByAge() {
        let sortedUsersList = Array.from(this._usersList_)
            .sort((a, b) => a[1]._uAge_ - b[1]._uAge_);
        return sortedUsersList;
    }
}

// Menu Driven 
console.log("Menu: ");
console.log("\t1: Add Users ");
console.log("\t2: Show All Users ");
console.log("\t3: Show All Users Order By Age");
console.log("\t4: Update User");
console.log("\t5: Delete User");
console.log("\t0: Exit");

let utilityObj;
let choiceYN = 'N';

do {
    let choice = parseInt(prompt("Enter Ur Choice"));

    switch (choice) {
        // Add User
        case 1: {
            utilityObj = new UserUtility();
            console.log('\n\n\tAll users are Added ');
        } break;

        // Show All Users
        case 2: {
            var usersList = utilityObj.getAllUsersList();
            console.log("\n\n\tBelow Given is the List of Users ..!");
            // Reading From an Map -> READ
            for (var [k, v] of usersList) {
                console.log(usersList.get(k).showAllUsers());
            }
        } break;

        // Show All Users Order By Age
        case 3: {
            console.log("\n\n\tAfter sorting in ascending order");
            let sortedUsersList = utilityObj.showAllUsersOrderByAge();
            for (var [k, v] of sortedUsersList) {
                console.log(usersList.get(k).showAllUsers());
            }
        }

        // Update User
        case 4: {
            console.log("\n\n\tAfter Updating user from the List ..!");

            if (utilityObj.updateUser()) {
                for (var [k, v] of usersList) {
                    console.log(usersList.get(k).showAllUsers());
                }
            }
            else {
                console.log("\n\n\tUser Does Not Exist ..!");
            }
        } break;

        // Delete User
        case 5: {
            console.log("\n\n\tAfter Deleting user from the List ..!");

            if (utilityObj.deleteUser()) {
                for (var [k, v] of usersList) {
                    console.log(usersList.get(k).showAllUsers());
                }
            }
            else {
                console.log("\n\n\tUser Does Not Exist ..!");
            }
        } break;

        default: {
            console.log("\n\n\tInvalid Choice ..! ");
        }
            break;
        case 0: {
            console.log("\n\n\tThank you ..! ");
            break;
        }
    }

    choiceYN = prompt("Do you wants to continue ?");
} while (choiceYN === 'Y' || choiceYN === 'y');