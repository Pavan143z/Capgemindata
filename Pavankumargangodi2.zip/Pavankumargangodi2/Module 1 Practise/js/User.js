class inventory {
    //Super Method
    getUserIn() {
        console.log("User In..(Super Methos)");
    }

    //Super Method
    getUserOut() {
        console.log("User In..(Super Methos)");
    }
}

class User extends inventory {
    //Constructor
    constructor(uId, uName, uAge, uCity) {
        super();
        this.uId= uId;
        this.uName= uName;
        this.uAge= uAge;
        this.uCity= uCity;
    }

    //Method to Show user Date
    printAllData() {
        let userDetails = 
                            `
                            User Id: ${this.uId}
                             User Name: ${this.uName}
                             User Age: ${this.uAge}
                             User City: ${this.uCity}
                            `;
    return userDetails;
    } 
    getUserIn() {
        super.getUserIn();

    }
    getUserOut() {
        super.getUserOut;
    }
}

// Creating Object of User Class


var userObj1 = new User(1002,"rahul",19,"Mumbai");
var userObj2 = new User(1003,"Ram",66,"Pune");
var userObj3 = new User(1001,"Penny",32,"Delhi");
var userObj4 = new User(1000,"Sheldon",30,"Delhi");

//Creating Map of User Data
let allUsers = new Map();

allUsers.set(1, userObj1);
userObj1.getUserIn();
allUsers.set(2, userObj2);
userObj2.getUserIn();
allUsers.set(3, userObj3);
userObj3.getUserIn();
allUsers.set(4, userObj4);
userObj4.getUserIn();

console.log("Displaying All User Data :");
for(let [k,v] of allUsers) {
    console.log(allUsers.get(k).printAllData());
}

//Sorting Data
let sortedMap = new Map([...allUsers.entries()]
    .sort((a, b) => a[1].uAge - b[1].uAge));
        console.log("Display Sorted User Data: ")

    for(let [k,v] of sortedMap) {
        console.log(sortedMap.get(k).printAllData());


    }


    //Accepting data from User
    let updateUserId = prompt("Enter UserId to update :");
    let updateUserIdResult = Array.from(allUsers).find( k=> k[1].uId == updateUserId);
    if(updateUserIdResult == undefined) 
    {
        console.log("User NOt Found .. Not Updated..");

        
    }
    else {
        updateUserIdResult[1].uName = "pavan";
        console.log("Displaying Updated User Data");

        for(let [k,v] of allUsers) {
        console.log("Displaying Updated User Data");
        
        
        for(let [k,v] of allUsers) {
            console.log(allUsers.get(k).printAllData());
    }
        }

        //Acceptance data from User
        let deleteUserId = prompt("Enter UserId to Delete :");
        let deleteUserIdResult = Array.from(allUsers).find( k=> k[1].uId == deleteUserId);
        if (deleteUserIdResult == undefined) 
        {
            console.log("User Not Found .. Not Deleted..");
    
            
        }
        else {
           allUsers.delete(deleteUserIdResult[0]);
          userObj1.getUserOut() +" "  + console.log(deleteUserId);
    
          
            console.log("Displaying Deleted Map");
            
            
            for(let [k,v] of allUsers) {
                console.log(allUsers.get(k).printAllData());
        }
    }
}