class Product{
    constructor(productId, productName, productPrice, productDescription){
        this._productId_= productId;
        this._productName_= productName;
        this._productPrice_= productPrice;
        this._productDescription_= productDescription;
    }
    //function
    printAllProduct(){
        var productDetails = 
                            `Product Id: ${this._productId_}
                             Product Name: ${this._productName_}
                             Product Price: ${this._productPrice_}
                             Product Description: ${this._productDescription_}
                            `;
    return productDetails;
    } 
} // end of Product class


class Product1 extends Product{
    constructor(productId,productName,productPrice,productDescription,productType){
        super(productId,productName,productPrice,productDescription);
        this._productType_= productType;
    }
    //function
    printAllProduct(){
        let allDetails= super.printAllProduct()+ " Product Type : "+this._productType_;
        return allDetails;
    }
}  //end of Product1 class
