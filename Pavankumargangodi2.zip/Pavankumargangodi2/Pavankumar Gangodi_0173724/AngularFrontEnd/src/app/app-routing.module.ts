import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './login/login.component';
import { ListUserComponent } from './component/list-user/list-user.component';
import { AddUserComponent } from './component/add-user/add-user.component';
const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'home',component:HomeComponent},
   {path:'login',component:LoginComponent},
     {path:'add-user',component:AddUserComponent},
   {path:'list-user',component:ListUserComponent}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
