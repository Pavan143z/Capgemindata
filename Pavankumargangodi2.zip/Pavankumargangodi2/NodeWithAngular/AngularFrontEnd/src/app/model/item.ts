export class Item{
    _id?:String;
    itemname:String;
    itemquantity:Number;
    itembought:Boolean
}