import { Component, OnInit } from '@angular/core';
import { Item } from './model/item';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ItemService } from './service/item.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  items:Item[];
addForm:FormGroup
  constructor(private itemservice:ItemService,
    private formbuilder:FormBuilder){
  }
  ngOnInit(){
       
}
  title = 'AngularFrontend';

  
}