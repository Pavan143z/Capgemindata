import { Component, OnInit } from '@angular/core';
import { Item } from '../model/item';
import { ItemService } from '../service/item.service';

@Component({
  selector: 'app-itemlist',
  templateUrl: './itemlist.component.html',
  styleUrls: ['./itemlist.component.css']
})
export class ItemlistComponent implements OnInit {
  shoppingitemlist:Item[]=[];
  

  constructor(private itemservice: ItemService) { }

  ngOnInit() {
   this.getitems();
  }

getitems()
{
  this.itemservice.getshoppingitems().subscribe(items=>{
    this.shoppingitemlist=<Item[]>items;
  });
}


addItem(frm){
  console.log(frm.value);
  let newitem: Item={
    itemname:frm.value.itemname,
    itemquantity:frm.value.itemquantity,
    itembought:false

  }
  this.itemservice.addshoppingitem(newitem).subscribe(item=>{
    console.log(item);
    this.getitems();
  })
}



deleteItem(id) {
  this.itemservice.deleteshoppingItem(id).subscribe(result => {
  console.log(result);
  
  for (var
  i = 0;
  i < this.shoppingitemlist.length;
  i++) {
  
  if (id ==
  this.shoppingitemlist[i]._id) {
  
  this.shoppingitemlist.splice(i,
  1);
  
  }
  
  }
  
  })
}
}