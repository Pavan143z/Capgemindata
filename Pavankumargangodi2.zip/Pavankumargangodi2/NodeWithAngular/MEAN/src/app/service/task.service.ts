import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Task } from 'src/app/model/task';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  baseUrl: string = " http://localhost:5000/api/item";

  constructor(private http: HttpClient) { }
  getTasks(){
    return this.http.get<Task[]>(this.baseUrl);
   }
   
   //get user by id
   getTasksById(id:number){
     return this.http.get<Task>(this.baseUrl+ "/"+id)
   }
 
  deletetask(id:number){
    return this.http.delete(this.baseUrl+ "/"+id)
  }
  
  //modifyuser
  edittask(task: Task){
   return this.http.put(this.baseUrl+ '/' + task.id, task);
  }
  
  createtask(task:Task){
    return this.http.post(this.baseUrl,task);  
  }
 }

