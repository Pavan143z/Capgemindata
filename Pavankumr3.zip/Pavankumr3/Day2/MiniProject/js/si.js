function usernameExist()

    if(localStorage.getItem("username").value != null)
    {

    }
    window.location = "../pages/login.html";

// logOff() function
function logOff() {
    var result = confirm("Do you want to LogOff...?");
    if (result) {
        // localStorage.length ->returns how many keys
        //stored inside the localStorage object
        localStorage.removeItem("username");
        //clears all keys in one go
        localStorage.clear();
        if (localStorage.getItem("username") == null ) {
            window.location = "../pages/login.html";
        }
    }
}
function calculateSI(pa, noy, roi)
{
    if (pa.value==""|| noy.value == "" || roi.value == "")
    {
        alert('Please fill all boxes...!');
        return;
    }


    var si = parseFloat(pa.value) *
                parseInt(noy.value) *
                    parseFloat(roi.value) / 100;
                    document.getElementById("result")
                    .innerHTML = "Simple Intrest is " + si;
}