function usernameExist()
{
    //sessionStorage.getItem("username")
    if(localStorage.getItem("username")== null){
 window.location = "../pages/login.html";
 return;
}
}
document.getElementById("welocome").innerHTML = "welcome to " + localStorage.getItem("username");

// logOff() function
function clearusername() {
    var result = confirm("Do you want to LogOff...?");
    if (result) {
        // localStorage.length ->returns how many keys
        //stored inside the localStorage object
      //  localStorage.removeItem("username");
        //clears all keys in one go
        localStorage.clear();
        if (localStorage.getItem("username") == null ) {
            window.location = "../pages/login.html";
        }
    }
}
function calculateSI(pa,noy,roi)
{
    if (pa.value==""|| noy.value == "" || roi.value == "")
    {
        alert('Please fill all boxes...!');
    }
 else
    {

     var si = parseFloat(pa.value) * parseInt(noy.value) * parseFloat(roi.value) / 100;
                    document.getElementById("result").innerHTML = "Simple Intrest is "+si;
    }
}