interface IPerson {
    firstName: string,
    lastName: string,
    showFullName: ()=>string
}

var customerObj: IPerson = {
    firstName:"Amit",
    lastName: "Prabhu",
    showFullName:()=>this.firstName +" "+this.lastName
}

console.log("Full Name of Customer : "+customerObj.showFullName());

//Reusing the functionality of interface
var studentobj: IPerson ={
    firstName:"Karthik",
    lastName:"Suresh",
    showFullName:():string=>this.firstName+" "+this.lastName

}

console.log("Full Name of Student :"+customerObj.showFullName());

//Interface to Interface Inheritance
interface IMusician extends IPerson {
    age:number,
    instrument:string

}


//var drummer: IMusician;
//or Type Assertion
var drummer = <IMusician>{};
drummer.firstName="Pavan";
drummer.lastName="Anand";
drummer.age=25;
drummer.instrument="Drums";

let details= `
                Drummer Name:${drummer.showFullName()}
                Drummer Age:${drummer.age}
                Drummer Instrument:${drummer.instrument}
                `
                console.log(details);
