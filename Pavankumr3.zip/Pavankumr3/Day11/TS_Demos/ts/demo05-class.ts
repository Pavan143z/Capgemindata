//Understanding Access Specifiers
//[public,private,protected]
class  MyClass {
    companyName: string = "IGATE";
}
//instance o keyword
var myClassObj = new MyClass();
console.log("instanceof Keyword:" +(myClassObj instanceof MyClass));

//Incase of private and protected below lines will give error
//Accessing public member outside class
console.log("Default Name : " +myClassObj.companyName);

//Incase of private and protected below lines will give error
//changing name
myClassObj.companyName= "capGemini";
//Accessing public member outside class
console.log("After NAme Change: "+myClassObj.companyName);


//Using constructor to initialize class members
class product {
    //member variables
    private firstNmuber:number;
    public secondNumber:number;
    //constructor and fucntion must be always public 
    //constructor overloading
    //archieving with default arguements and optional parameter
    
}
    