//Base Type of Built - in Data Types and Custom Types
//Dynamic Type
var someType = 10;
//calss Name for Number Type is Number
console.log("someType here: typeOf: " + typeof (someType));
someType = "Hello World";
//class Name for string Type is String
console.log("sometype here : typeOf: " + typeof (someType));
//class NAme for boolean type is Boolean
someType = true;
console.log("sometype here : typeOf: " + typeof (someType));
someType = null;
console.log("sometype here : typeOf: " + typeof (someType));
someType = undefined;
console.log("sometype here : typeOf: " + typeof (someType));
//Declaring Variables
//Static Types -Once you declare any variable with some Type
//through the scope, it can't take anyother type
var eid = 101;
var ename = "Pavan";
var salary = 35000.00;
var empStatus = true;
//Displaying Variables
console.log("Employee Id is " + eid);
console.log("Employee Name is " + ename);
console.log("Employee salary is " + salary);
if (empStatus)
    console.log("Employee is Selected...");
else
    console.log("Employee is Rejected...");
//SET of Named String Intiger Constants
var Days;
(function (Days) {
    Days[Days["SUNDAY"] = 0] = "SUNDAY";
    Days[Days["MONDAY"] = 1] = "MONDAY";
    Days[Days["TUESDAY"] = 2] = "TUESDAY";
    Days[Days["WEDNSDAY"] = 3] = "WEDNSDAY";
    Days[Days["THURSDAY"] = 4] = "THURSDAY";
    Days[Days["FRIDAY"] = 5] = "FRIDAY";
    Days[Days["SATURDAY"] = 6] = "SATURDAY";
})(Days || (Days = {}));
console.log(Days.SUNDAY);
