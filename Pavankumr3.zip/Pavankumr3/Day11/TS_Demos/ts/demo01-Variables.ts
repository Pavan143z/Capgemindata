//Base Type of Built - in Data Types and Custom Types
//Dynamic Type
var someType: any = 10;
//calss Name for Number Type is Number
console.log("someType here: typeOf: "+typeof(someType));

someType = "Hello World";
//class Name for string Type is String
console.log("sometype here : typeOf: "+typeof(someType));

//class NAme for boolean type is Boolean
someType = true;
console.log("sometype here : typeOf: "+typeof(someType));

someType = null;
console.log("sometype here : typeOf: "+typeof(someType));

someType = undefined;
console.log("sometype here : typeOf: "+typeof(someType));

//Declaring Variables
//Static Types -Once you declare any variable with some Type
//through the scope, it can't take anyother type
var eid:number = 101;
var ename:string = "Pavan";
var salary:number = 35000.00;
var empStatus:boolean = true;

//Displaying Variables
console.log("Employee Id is "+eid);
console.log("Employee Name is "+ename);
console.log("Employee salary is "+salary);

if(empStatus)
    console.log("Employee is Selected...");
 else
    console.log("Employee is Rejected...");


   //SET of Named String Intiger Constants
    
enum Days {
   SUNDAY, MONDAY, TUESDAY, WEDNSDAY, THURSDAY, FRIDAY, SATURDAY
}

console.log(Days.SUNDAY)