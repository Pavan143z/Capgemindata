//Declaring Variables
var eid = 101;
var ename = "Pavan";
var salary = 35000.00;
var empStatus = true;
//Displaying Variables
console.log("Employee Id is " + eid);
console.log("Employee Name is " + ename);
console.log("Employee salary is " + salary);
if (empStatus)
    console.log("Employee is Selected...");
else
    console.log("Employee is Rejected...");
