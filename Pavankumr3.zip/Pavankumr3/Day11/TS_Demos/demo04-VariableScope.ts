var global_Num:number =100;

class VariableScope{

     //by default class member -meaning variable and functions are public in Typescript
    //instance variable which requires object to access
    //life time for this variable is depends on objects
    //it is bound to object
    instance_Num:number =10;

    //class variable or static variable which requires class name
    //life time for this variable is depends on class
    //it is bound to class
    static static_Num:number =1000;

    //non static function
      //non static function can access non static members and static members
      //by default class member are public in Typescript
    displayNum(local_Num:number=5):void{
        console.log("global_Num : " +global_Num);
        console.log("instance_Num : "+this.instance_Num);
        console.log("local_Num : "+ local_Num);
        console.log("static_Num : "+ VariableScope.static_Num);
    }
    //static function
    //static function can acces only static members
    //non static members not allowed
    //But you can declare non static members inside static function
    static displayStaticNumber(): void{
        console.log(VariableScope.static_Num);
        //console.log("instance_Num :" +this.instance_Num);
        //non static member dcleration
        //let num: number=20;
    }

}

var obj =new VariableScope();
console.log("\n\tglobal_Num : "+global_Num);

console.log("VariableScpe.static_Num :" +VariableScope.static_Num);

//calling with default paameter
obj.displayNum();
// calling with  parameter
obj.displayNum(20);