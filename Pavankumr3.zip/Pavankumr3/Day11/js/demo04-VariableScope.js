var global_Num = 100;
var VariableScope = /** @class */ (function () {
    function VariableScope() {
        //by default class member -meaning variable and functions are public in Typescript
        //instance variable which requires object to access
        //life time for this variable is depends on objects
        //it is bound to object
        this.instance_Num = 10;
    }
    //non static function
    //non static function can access non static members and static members
    //by default class member are public in Typescript
    VariableScope.prototype.displayNum = function (local_Num) {
        if (local_Num === void 0) { local_Num = 5; }
        console.log("global_Num : " + global_Num);
        console.log("instance_Num : " + this.instance_Num);
        console.log("local_Num : " + local_Num);
        console.log("static_Num : " + VariableScope.static_Num);
    };
    //static function
    //static function can acces only static members
    //non static members not allowed
    //But you can declare non static members inside static function
    VariableScope.displayStaticNumber = function () {
        console.log(VariableScope.static_Num);
        //console.log("instance_Num :" +this.instance_Num);
        //non static member dcleration
        //let num: number=20;
    };
    //class variable or static variable which requires class name
    //life time for this variable is depends on class
    //it is bound to class
    VariableScope.static_Num = 1000;
    return VariableScope;
}());
