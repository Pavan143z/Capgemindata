
class Product{
    constructor(productId, productName, productPrice, productDescription){
        this._productId_= productId;
        this._productName_= productName;
        this._productPrice_= productPrice;
        this._productDescription_= productDescription;
    }
    //function
    printAllProduct(){
        var productDetails = 
                            `Product Id: ${this._productId_}
                             Product Name: ${this._productName_}
                             Product Price: ${this._productPrice_}
                             Product Description: ${this._productDescription_}
                            `;
    return productDetails;
    } 
} // end of Product class


class Product1 extends Product{
    constructor(productId,productName,productPrice,productDescription,productType){
        super(productId,productName,productPrice,productDescription);
        this._productType_= productType;
    }
    //function
    printAllProduct(){
        let allDetails= super.printAllProduct()+ " Product Type : "+this._productType_;
        return allDetails;
    }
}  //end of Product1 class

class Product2 extends Product{
    constructor(productId,productName,productPrice,productDescription,productCategory){
        super(productId,productName,productPrice,productDescription);
        this._productCategory_= productCategory;
    }
    //function
    printAllProduct(){
        let allDetails= super.printAllProduct()+ " Product Category : "+this._productCategory_;
        return allDetails;
    }
}  //end of Product2 class

var product1Obj = new Product1("P1", "Laptop", 50000,"My Laptop","Education");
console.log(product1Obj.printAllProduct());

var product2Obj = new Product2("P2", "Refrigerator", 40000,"To make things cool","Home Appliance");
console.log(product2Obj.printAllProduct());

var product3Obj = new Product1("P3", "Washing Machine", 45000,"To wash clothes","Home Appliance");
console.log(product1Obj.printAllProduct());

var product4Obj = new Product2("P4", "Television", 60000,"To entertain","Home Appliance");
console.log(product2Obj.printAllProduct());

let allProducts = [];

//adding to array-> create
allProducts.push(product1Obj);
allProducts.push(product2Obj);
allProducts.push(product3Obj);
allProducts.push(product4Obj);
//reading from an array-> read
//Updating from an array
let productId= prompt("Enter Product ID");
    for (var product in allProducts){
       console.log(allProducts[product].printAllProduct());
    }
 
console.log("After sorting in ascending order");
allProducts.sort((a,b)=> a._productPrice_- b._productPrice_);

for (var product in allProducts){
    console.log(allProducts[product].printAllProduct());
 }

// for (var product in allProducts){
//     if(allProducts[product]._productId_ === productId){
//         allProducts[product]._productName_ = "HP Laptop";
//     }
// }
// console.log("After changing product name: ");
// for (var product in allProducts){
//     console.log(allProducts[product].printAllProduct());
// }


// for (var product in allProducts){
//     if(allProducts[product]._productId_ === productId){
//         allProducts.splice(product,1 );
//     }
// }
// console.log("After removing product : ");
// for (var product in allProducts){
//     console.log(allProducts[product].printAllProduct());
// }