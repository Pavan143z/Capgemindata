// constructors in the order of base to derived
class BaseClass{
    constructor(){
        console.log("Base Class is called..!");
    }
}

//Inherting from Base class
class DerivedClass extends BaseClass{
    constructor(){
                // super() is mandatory in derived class
        super();
        console.log("Derived class is called..!");
    }
}

let derivedObj = new DerivedClass();
//O/P: Base class is called..!
// Derived class is called..!

//Parent class or super class 
class Employee{
    constructor(id, name, salary){
        this._id_ = id;
        this._name_ = name;
        this._salary_ = salary;
    }
    //base class function
    showDetails(){
        let details = `Emp Id: ${this._id_}
                       Name: ${this._name_}
                       Salary: ${this._salary_} 
                      `;
        return details;
    }
}

//Child class or sub class
class Manager extends Employee{
    constructor(id, name, salary, deptName){
        //super keyword is used to call
        //base class constructors to initialize
        //derived class members
        super(id, name, salary);
        this._deptName_ = deptName;
    }
    //overriding base class function inside derived class is called as function overriding
    showDetails(){
        return "Department Name: "+this._deptName_+" "+super.showDetails();
    }
}

var mgrObj = new Manager(101, "Pavan", 25000, "IT");
console.log(mgrObj.showDetails());

//super keyword points to immediate base class
//super keyword in derived class, it is used to invoke base class constructor
//super keyword is also used to invoke base classs members and fun
//it avoids ambiguity between base class members and derived class members

class SuperClass{
    constructor(){
        this._cid_ = 20;
    }
    display(){
        return this._cid_;
    }
}
class SubClass extends SuperClass{
    constructor(){
        super();
        this._id_ = 10;
    }
    display(){
        console.log("Instance variable: "+this._id_);
        console.log("Super variable: "+super.display());
    }
}
let subObj = new SubClass();
subObj.display();
