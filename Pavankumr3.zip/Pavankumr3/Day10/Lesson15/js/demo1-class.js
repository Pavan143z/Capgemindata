// Create class rectangle
//area of rectangle
class Rectangle{
    constructor(){
        console.log("Constructor of Rectangle class is called..!");
    }

    calculateArea(r){
        let area = 3.142 * r * r;
        return area;
    }
}

let rectObj = new Rectangle();
let radius = parseFloat(prompt("Enter radius : "));

let area = rectObj.calculateArea(radius);
console.log(area);

// To calculate are of square
class Square{
    constructor(){
        console.log("Constructor of Square class is called..!");
    }

    calculateArea(r){
        let area = 3.142 * r * r;
        return area;
    }
}

let squareObj = new Square();
let rad = parseFloat(prompt("Enter radius : "));

let area1 = rectObj.calculateArea(rad);
console.log(area1);