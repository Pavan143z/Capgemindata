//Base class
class Shape{
    constructor(radius, length, breadth){
        this._radius_ = radius;
        this._length_ = length;
        this._breadth = breadth;
    }
    calculateArea()
        {
            console.log("This is Shape class");
        }
}

// Derived class Circle 
class Circle extends Shape{
    constructor(radius){
        super(radius);
        //this._radius_ = radius; 
    }
    calculateArea()
        {
            let area = 3.142* this._radius_ *this._radius_;
            return area;
        }
}

//Derived class Rectangle
class Rectangle extends Shape{
    constructor(length,breadth){
        super(length,breadth);
        this._length_ = length;
        this._breadth_ = breadth;
    }
    calculateArea()
    {
        let area1= this._length_ * this._breadth_;
        return area1;
    }
}

let circleObj = new Circle(radius=5);
let area2= circleObj.calculateArea();
console.log("Area of Circle is "+area2);

let rectObj = new Rectangle(length= 5, breadth = 6);
let area3= rectObj.calculateArea();
console.log("Area of Rectangle is "+area3);
