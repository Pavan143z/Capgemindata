class Mobile{
    constructor(mobId, mobName, mobCost){
        this._mobId_= mobId;
        this._mobName_= mobName;
        this._mobCost_= mobCost;
    }
    //function
    printMobileDetail(){
        var mobileDetails = 
                            `Mobile Id: ${this._mobId_}
                             Mobile Name: ${this._mobName_}
                             Mobile Cost: ${this._mobCost_}
                            `;
    return mobileDetails;
    } 
} // end of Mobile class
class BasicPhone extends Mobile{
    constructor(mobId, mobName, mobCost,mobType){
        super(mobId, mobName, mobCost);
        this._mobType_= mobType;
    }
    printMobileDetail(){
        let allDetails= super.printMobileDetail()+"Basic Phone Type : "+this._mobType_;
        return allDetails;
    }
}
class SmartPhone extends Mobile{
    constructor(mobId, mobName, mobCost,mob1Type){
        super(mobId, mobName, mobCost);
        this._mob1Type_= mob1Type;
    }
    printMobileDetail(){
        let allDetails= super.printMobileDetail()+"Smart Phone Type : "+this._mob1Type_;
        return allDetails;
    }
}
console.log("List of mobiles...!");
var mobile1Obj= new BasicPhone(10,"Samsung",10000,"Basic Phone");
console.log(mobile1Obj.printMobileDetail());
var mobile2Obj= new SmartPhone(11,"Redmi",34000,"Smart Phone");
console.log(mobile2Obj.printMobileDetail());

let allMobiles = [];

//adding to array-> create
allMobiles.push(mobile1Obj);
allMobiles.push(mobile2Obj);
//reading from an array-> read
//Updating from an array
let mobId= parseInt(prompt("Enter Mobile ID"));
for (var mobile in allMobiles){
    if(allMobiles[mobile]._mobId_ === mobId){
        allMobiles[mobile]._mobName_ = "Redmi Note 6 Pro";
    }
}
console.log("After changing Mobile name: ");
for (var mobile in allMobiles){
    console.log(allMobiles[mobile].printMobileDetail());
}
//deleting 
for (var mobile in allMobiles){
    if(allMobiles[mobile]._mobId_ === mobId){
        allMobiles.splice(mobile,1 );
    }
}
console.log("After removing mobile : ");
for (var mobile in allMobiles){
    console.log(allMobiles[mobile].printMobileDetail());
}