
class Product{
    constructor(productId, productName, productPrice, productDescription){
        this._productId_= productId;
        this._productName_= productName;
        this._productPrice_= productPrice;
        this._productDescription_= productDescription;
    }
    //function
    printAllProduct(){
        var productDetails = 
                            `Product Id: ${this._productId_}
                             Product Name: ${this._productName_}
                             Product Price: ${this._productPrice_}
                             Product Description: ${this._productDescription_}
                            `;
    return productDetails;
    } 
} // end of Product class


class Product1 extends Product{
    constructor(productId,productName,productPrice,productDescription,productType){
        super(productId,productName,productPrice,productDescription);
        this._productType_= productType;
    }
    //function
    printAllProduct(){
        let allDetails= super.printAllProduct()+ " Product Type : "+this._productType_;
        return allDetails;
    }
}  //end of Product1 class

class Product2 extends Product{
    constructor(productId,productName,productPrice,productDescription,productCategory){
        super(productId,productName,productPrice,productDescription);
        this._productCategory_= productCategory;
    }
    //function
    printAllProduct(){
        let allDetails= super.printAllProduct()+ " Product Category : "+this._productCategory_;
        return allDetails;
    }
}  //end of Product2 class

var product1Obj = new Product1("P1", "Laptop", 50000,"My Laptop","Education");
console.log(product1Obj.printAllProduct());

var product2Obj = new Product2("P2", "Refrigerator", 40000,"To make things cool","Home Appliance");
console.log(product2Obj.printAllProduct());

var product3Obj = new Product1("P3", "Washing Machine", 45000,"To wash clothes","Home Appliance");
console.log(product1Obj.printAllProduct());

var product4Obj = new Product2("P4", "Television", 60000,"To entertain","Home Appliance");
console.log(product2Obj.printAllProduct());

//creating set object using Set() constructor
let allProducts = new Set();

//adding to array-> create
allProducts.add(product1Obj);
allProducts.add(product2Obj);
allProducts.add(product3Obj);
allProducts.add(product4Obj);
//reading from an array-> read
//Updating from an array
let productId= prompt("Enter Product ID");

for (var product of allProducts){
    console.log(product.printAllProduct());
 }


productId= prompt("Enter Product ID to update : ");
let updatedProduct = Array.from(allProducts).find(p=> p._productId_ === productId);
updatedProduct._productName_= "HP Laptop";
updatedProduct._productPrice_ = "58000";
updatedProduct._productDescription_ = "Better Features";
updatedProduct._productCategory_ = "Education";
console.log("After updating the product");
   for(var product of allProducts){
        console.log(product.printAllProduct());
   }

console.log("After sorting in ascending order");
let sortedSet = Array.from(allProducts).sort((a,b)=> a._productPrice_- b._productPrice_);

for (var product of sortedSet){
 console.log(product.printAllProduct());
}
// productId= prompt("Enter Product ID to delete : ");
// deleting product
// let deleteProduct = Array.from(allProducts).find(p=> p._productId_ === productId);
// allProducts= delete(deleteProduct);

// console.log("After removing product : ");
 
//      console.log(product.printAllProduct());
 
// for (var product of sortedSet){
//     if(product._productId_ === productId){
//           product._productName_ = "HP Laptop";
//           product._productPrice_ = "58000";
//           product._productDescription_ = "Better Features";
//           product._productCategory_ = "Education";
//       }
//   }
//   console.log("After changing product name: ");
//   for (var product of sortedSet){
//       console.log(product.printAllProduct());
//   }

//     for (var product in allProducts){
//        console.log(allProducts[product].printAllProduct());
//     }
 
// console.log("After sorting in ascending order");
// allProducts.sort((a,b)=> a._productPrice_- b._productPrice_);

// for (var product in allProducts){
//     console.log(allProducts[product].printAllProduct());
//  }

// for (var product in allProducts){
//    if(allProducts[product]._productId_ === productId){
//          allProducts[product]._productName_ = "HP Laptop";
//      }
//  }
//  console.log("After changing product name: ");
//  for (var product in allProducts){
//      console.log(allProducts[product].printAllProduct());
//  }


// for (var product in allProducts){
//     if(allProducts[product]._productId_ === productId){
//         allProducts.splice(product,1 );
//     }
// }
// console.log("After removing product : ");
// for (var product in allProducts){
//     console.log(allProducts[product].printAllProduct());
// }