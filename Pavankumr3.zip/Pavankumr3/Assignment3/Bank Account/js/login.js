function login(frmLoginObj){
    if(frmLoginObj.checkValidity())  {
        var username = frmLoginObj.txtUN.value;
        var password = frmLoginObj.txtPD.value;

        if(username == "pavan" && password == "1234")
        {
            alert('Login Successful ..!');
            localStorage.setItem("username", username);
            window.location = "../pages/registration.html";
            //alert(window.location);
        }
        else
        alert('Login Failed ..! ');
    }

}