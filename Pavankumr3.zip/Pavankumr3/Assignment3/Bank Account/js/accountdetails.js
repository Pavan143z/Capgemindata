function afterSubmit(registerForm){
    if(registrationForm.checkValidity()){
        if(validateCustIID)(registerForm.txtCustID) && validateAccNumber(registerForm.txtAccNumber) &&validateOpeningAmt(registerForm.txtOpeningAmt)
        alert('Account Creation Successful  ..!!');

        var txtCustID = registerForm.txtCustID.value;
        var txtName = registerForm.txtName.value;
        var Address = registerForm.txtAddress.value;
        var Age=registerForm.Age.value;
        var txtUsername = registerForm.textUsername.value;
        var txtPassword= registerForm.txtpassword.value;
        var rbntAccType = registerForm.rbntAccType.value;
        txtAccNumber=registerForm.txtAccNumber.value;
        var txtOpeningAmt = registerForm.txtOpeningAmt.value;
        var sessionID='On'


        localStorage.setItem("txtCustID",txtCustID);
        localStorage.setItem("txtName",txtName);
        localStorage.setItem("Address",Address);
        localStorage.setItem("Age",Age);
        localStorage.setItem("txtUsername",txtUsername);
        localStorage.setItem("txtPassword",txtPassword);
        localStorage.setItem("rbntAccType",rbntAccType);
        localStorage.setItem("txtOpeningAmt",txtOpeningAmt);
     
      localStorage.setItem("sessionID",sessionID);



        
    }
}