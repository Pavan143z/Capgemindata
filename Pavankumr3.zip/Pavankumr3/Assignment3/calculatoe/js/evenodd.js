function checkEvenorOdd(num)
{
    var result;
    if(num.value==0)
    
    result="0 is neither Even Nor Odd...!"
    
    
    else if(num.value % 2== 0)
    
    result=num.value+ "is a Even Number...!";
    
    else
    
    result=num.value+ "is a Odd Number...!";
    alert(result);
    
}
    

function displayDays(month, year){
    var days;
    switch (parseInt(month.value)) 
    {
        case 1:
            
       

        case 3:

        case 5:

        case 7:

        case 8:

        case 10:

        case 12:
        {
            days = 31;
        }
        break;
        case 4:

        case 6:

        case 9:

        case 11:
        {
            days =30;
        }
        break;
    case 2:{
        if(year.value%4==0)
        {
            days=29;
        }
        else{
            days=28;
        }
    }
    break;
    default:{
        days=-1;
    }
}


if(days==-1)
{
    alert("Invalid Month")
}
else
alert(month.value+"has "+days+" days");
}
function checkValue(num1,num2)
{
    var result=(num1.value=num2.value?"Both are equal":num1.value>num2.value? is greater than number2":"number2is greater than number1");
}