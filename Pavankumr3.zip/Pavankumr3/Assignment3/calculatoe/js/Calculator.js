function cal(math)
{
    var n1=parseInt(document.getElementById("txtFN").value);
    var n2=parseInt(document.getElementById("txtSN").value);

switch(math){


    case "Addition":
            var result=n1+n2;
            alert(result);
            break;
    case "Substraction":
            var result=n1-n2;
            alert(result);
            break;
    case  "Multiplication":
            var result=n1*n2;
            alert(result);
            break;
    case "Division":
            var result=n1/n2;
            alert(result);
            break;
    default:
            alert("Enter Valid Creditinals");

}
}