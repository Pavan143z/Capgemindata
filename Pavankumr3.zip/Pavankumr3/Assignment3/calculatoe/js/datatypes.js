var anyType;

document.write("Type: "+typeof(anyType)+"   "+"value: "+anyType);

anyType = "Narendra";
document.write("</br>Type: "+typeof(anyType)+"   "+"value: "+anyType);

anyType = "1000";
document.write("</br>Type: "+typeof(anyType)+"   "+"value: "+anyType);

anyType = "false";
document.write("</br>Type: "+typeof(anyType)+"   "+"value: "+anyType);

anyType = "null";
document.write("</br>Type: "+typeof(anyType)+"   "+"value: "+anyType);


