var listofBoys =["Pavan","Prabhas","Samantha"];
var listofGirls =new Array("Priya","Madhavi","Sneha");


// Empty Decleration 
//var numbers=[];
//declaring and initializing an array in onel ine

document.write("<h3>"+listofBoys + "</h3>");
document.write("<h3>"+listofGirls + "</h3>");

document.write("<h3>Display Boys Using loops</h3>");
document.write("<h4>Boys Count:" + listofBoys.length + "</h4>");

for(var i=1; i<listofBoys.length;i++)
document.write(listofBoys[i].bold().italics() + "<br/>");


listofBoys.push("Vikash");
document.write("<h3>Displaying Boys After Adding Mukund</h3>");
document.write("<h3>" + listofBoys + "</h3>");
document.write("<h4> Boys count:"+ listofBoys.length + "</h4>");


document.write("<h3>Girls Count: " +listofGirls.length+"</h3>");
document.write("<h3>Display Girls using loops</h3>");


for(var i=1; i<listofGirls.length;i++)
document.write(listofGirls[i].bold().italics() + "<br/>");


listofBoys.unpush("Shreya");
document.write("<h3>Displaying Girls After Adding Shreya</h3>");
document.write("<h3>" + listofBoys + "</h3>");
document.write("<h4> Girls count:"+ listofGirls.length + "</h4>");

listofGirls.pop();
document.write("<h3>"+ listofGirls+"</h3>");
document.write("<h4> Girls count:"+ listofGirls.length + "</h4>");

document.write("<h3>Sort Girls in Ascending Order</h3>");
listofGirls.sort();
for(var i=1; i<listofGirls.length;i++)
document.write(listofGirls[i].bold().italics() + "<br/>");
document.write("<h3>Sort Girls in Descending Order</h3>");

var listofParticipants = listofGirls.concat(listofBoys);
document.write("<h3> Final List in Ascending Order</h3>");
listofParticipants.sort();
for(var i=0; i<listofParticipants.length ;i++)
document.write(listofParticipants[i].bold().italics() + "<br/>");

