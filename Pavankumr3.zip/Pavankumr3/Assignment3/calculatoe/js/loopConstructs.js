
function findfactorial_ForLoop(num){
  
    if(num.value==" " || isFinite(num.value))
    alert("Plz Enter Only Numeric value ..!")
    else{
        var n= parseInt(num.value);
        var fact=1;
        for(var i=1;i<=n;i++)
        fact *=i;
        alert ("Factorial of "+n+   " is "+fact);
    }
}
function findfactorial_WhileLoop(num){

    if(num.value==" " || isFinite(num.value))
    alert("Plz Enter Only Numeric value ..!")
    else{
        var n= parseInt(num.value);
        var fact=1;
        // 1)initialization
        var i=1;
     where (i<=n)
        fact *=i;//3)
        i++; //4)Inc/dec
        alert ("Factorial of "+n+" is :"+fact);
    }
}
function function_Arguments(separator)
{
    var result;
    for(var i=1;i<arguments.length;i++)
    result +=argument[i]+separator;
    document.write("<h2>"+result+"</h2>");
}
function addition(){
    var sum=0;
    for( var i=0;i<=arguments.length;i++)
    sum+=parseInt(argument[i]);
    return sum;

document.write("<h3>addition(10,20,30) :" +addition(10,20,30)+"</h3>")
document.write("<h3>addition(10,20,30) :" +addition(10,20,30)+"</h3>")
document.write("<h3>addition(10,20,30) :" +addition(10,20,30)+"</h3>")
}