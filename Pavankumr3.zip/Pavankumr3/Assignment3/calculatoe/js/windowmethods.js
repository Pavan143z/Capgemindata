function calculateACircle()
{
    var radius = parseFloat(prompt("enter radius: "));

    var area=Math.PI* radius * radius;

    alert("Area of Circle is " +area);
    
    var result=confirm("Do you want to continue ?");
    if(result == true)
    {
        calculate();
    }
}
var intervalObj;
function setIntervalFunc(){
    intervalObj = setInterval(function(){
        alert('Hello World');
    },2000);
}
function clearIntervalFunc(){
    clearInterval(intervalObj);
    alert('U have Stopped Interval ...!');
}

var TimeOutObj;
function setTimeOutFunc(){
    alert('U have started Timeout...!');
    TimeOutObj = setTimeOut(function(){
        alert('Hello World');
    },3000);
}
function clearTimeOutFunc()
{
    clearTimeout(TimeOutObj);
    alert('U have Stopped TimeOut ...!');
}
function display()
{
    var message =this.id+" "+this.name+" "+this.desig+" "+this.salary;
    alert(message);

}
var emp1=new Object;
emp1.id=101;
emp1.name="anand";
emp1.desig="Doveloper";
emp1.salary=45000;
emp1.displayEmp=display;
emp1.displayEmp();


var emp1=new Object;
emp2.id=102;
emp2.name="pavan";
emp1.desig="tester";
emp2.salary=25000;
emp2.displayEmp=display;
emp2.displayEmp();


