document.write("<h2>For Loop:</h2>");
document.write("<table border='1'><tr><td>");
for (var i = 0; i < 100; i++) {
    if ((i + 1) % 10 != 0) {
        document.write(i + " ");
    }
    else {
        document.write(i + "</br>");
    }
}
document.write("</td></tr></table>");

document.write("<h2>While Loop:</h2>");
document.write("<table border='1'><tr><td>");
var j = 0;
while (j < 100) {
    if ((j + 1) % 10 != 0) {
        document.write(j + " ");
    }
    else {
        document.write(j + "</br>");
    }
    j++;
}
document.write("</td></tr></table>");

document.write("<h2>Do While Loop:</h2>");
document.write("<table border='1'><tr><td>");
var k = 0;
do {
    if ((k + 1) % 10 != 0) {
        document.write(k + " ");
    }
    else {
        document.write(k + "</br>");
    }
    k++;
}
while (k < 100);
document.write("</td></tr></table>");

