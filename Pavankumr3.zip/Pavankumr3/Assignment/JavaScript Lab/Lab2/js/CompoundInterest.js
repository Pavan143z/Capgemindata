var principalAmt=1000;
var rateOfInterest=10;
var periodYear=1;

var compoundInterest=(principalAmt*(1+Math.pow((rateOfInterest/100),periodYear)))-principalAmt;

document.getElementById("principalAmt").innerHTML=principalAmt;
document.getElementById("rateOfInterest").innerHTML=rateOfInterest;
document.getElementById("periodYear").innerHTML=periodYear;
document.getElementById("compoundInterest").innerHTML=compoundInterest;

