function calculateBill(frmBillingObj){
    //alert('1')
    if(frmBillingObj.checkValidity()){
        //alert('2');
        //console.log('2');

        var title=frmBillingObj.ddTitle.value;
        var name=frmBillingObj.txtName.value;
        var carType=frmBillingObj.ddCarType.value;
        var serviceType=frmBillingObj.rbtnService.value;
        var costOfTheVehicle= parseFloat(frmBillingObj.txtCost.value);

        var billingCost;
        if(serviceType=="free service")
        serviceCharge= 200;
        else if(serviceType== "body repair")
        {
            //alert('3');
            if(carType=="hatchback")
            serviceCharge=0.15*costOfTheVehicle;
            else if(carType=="smallcars")
            serviceCharge = 0.10*costOfTheVehicle;
            else 
            serviceCharge = 0.18*costOfTheVehicle;
        }
        var message= "Thanks for Visit "+title+". "+name+ ". Cost of Service is " +serviceCharge;
        alert(message);

    }
}
