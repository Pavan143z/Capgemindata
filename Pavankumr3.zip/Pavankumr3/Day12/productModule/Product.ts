 export class product {
    produtId: number;
    productName: string;

}
export const company:string = "Capgemini";