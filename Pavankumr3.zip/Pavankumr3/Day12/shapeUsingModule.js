"use strict";
exports.__esModule = true;
function drwaAllShapes(shapeToDraw) {
    shapeToDraw.draw();
    {
        console.log("Circle is drwan (external module)");
    }
}
