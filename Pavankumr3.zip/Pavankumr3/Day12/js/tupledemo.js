//Tuples
//At times,there might be need to store a collection of values
//of varied types.Arrays will not serve this purpose
var studentTupleObj = [101, "Pavan"];
console.log(studentTupleObj[0]);
console.log(studentTupleObj[1]);
var customerTuple = [101, "Shrey", "Pune", "Laptop"];
//returns the tuple size
console.log("Items before push " + customerTuple.length);
//append value to the tuple
customerTuple.push(50000);
console.log("customerTuple after push " + customerTuple.length);
console.log("customerTuple before pop " + customerTuple.length);
//removes and returns the last item
console.log(customerTuple.pop() + " popped from the tuple");
console.log("customerTuple after pop " + customerTuple.length);
//destructing a tuple
var empObj = [101, "Amit"];
var id = empObj[0], ename = empObj[1];
console.log(id);
console.log(ename);
