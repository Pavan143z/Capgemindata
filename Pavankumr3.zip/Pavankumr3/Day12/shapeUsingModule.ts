
import{ IShape } from "./Shape Module/IShape";
import { Circle } from "./Shape Module/Circle";
import{ Triangle } from "./Shape Module/Traingle";

function drwaAllShapes(shapeToDraw: IShape)
{
    shapeToDraw.draw()
    {
        console.log("Circle is drwan (external module)");
    }
}