//import shape=require("./IShape");
//export class circle implements shape.IShape{
    //public draw(){
    //    console.log(Circle is drawn (external module)");
  //  }
//}


//OR


import { IShape } from "./IShape";
export class Circle implements IShape {
    public draw() {
        console.log("Circle is drawn (external module)");
    }
    public area(radius: number): number {
        let areaOfCircle = 3.142 * radius * radius;
        return areaOfCircle;
    }
}
