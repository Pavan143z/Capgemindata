
import{ IShape } from "./IShape";

export class Triangle implements IShape{
    public draw(){
        console.log("Triangle is drawn (external module)");
    }
    public area(length: number,breadth: number): number {
        let areaOfTriangle= length *breadth;
        return areaOfTriangle;
    }
}