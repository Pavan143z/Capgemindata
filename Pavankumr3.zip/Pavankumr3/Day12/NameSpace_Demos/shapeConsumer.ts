//import { Shapes } from "./shapes";
//let triangleObj=new shapes.Shapes.Triangle();//shapes.Shapes?
//console.log(triangleObj.show());




import { Shapes } from "./shapes";
let triangleObj = new Triangle();
console.log(triangleObj.show());