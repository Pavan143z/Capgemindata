//namespace Geomtrical {

        export namespace Shapes {
            
            export class Triangle {
                show():string{
                    return "Triangle";
                }
            }
            export class Square {
                show():string{
                    return "Square";
                }
            }
        }
//}
//Old way of importing namespace in javascript
/// <reference path=""/>