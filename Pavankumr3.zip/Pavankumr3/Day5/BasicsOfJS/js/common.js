/* Here, showDate is Global Variable and 
Data is built in core objects in JavaScript */
var showDate = new Date();

/* This function will be invoked on [onload] event */
function showDateTime() {
document.getElementById("showDate").innerHTML
        ="Today's Date and Time is "+ showDate;
}