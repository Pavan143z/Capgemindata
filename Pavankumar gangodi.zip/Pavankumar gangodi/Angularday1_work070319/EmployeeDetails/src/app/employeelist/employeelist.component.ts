import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.css']
})
export class EmployeelistComponent implements OnInit {

  constructor() { }
  title = "Employee List"
    employee:any[]=[
      {
        code:"emp101",
        name:'Rashmi',
        gender:'female',
        annualSalary:40000,
        dateOfBirth:'05/10/1985'
      },
      {
        code:"emp201",
        name:'Pavan',
        gender:'Male',
        annualSalary:30000,
        dateOfBirth:'06/21  /1996'
      },
      {
        code:"emp301",
        name:'Kumar',
        gender:'Male',
        annualSalary:20000,
        dateOfBirth:'01/01/1984'
      }
    ];
  ngOnInit() {
  }

}
