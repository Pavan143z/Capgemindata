import { NgModule } from '@angular/core';
import {Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { EventComponent } from './event/event.component';
import { TemplateDivenFormComponent } from './template-diven-form/template-diven-form.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { LoginComponent } from './login/login.component';
import { ProductComponent } from './product/product.component';
import { AuthGuard } from './guards/auth.guard';
import { ParentComponent } from './parent/parent.component';

const routes: Routes = [
 
      {path:'',component:HomeComponent},
      
      {path:'about',component:AboutComponent,canActivate:[AuthGuard]},
      {path:'contact',component:ContactComponent,canDeactivate:[AuthGuard]},
      {path:'employeelist',component:EmployeelistComponent},
      {path:'event',component:EventComponent},
      {path:"Template",component:TemplateDivenFormComponent},
      {path:"Reactive",component:ReactiveFormComponent},
      {path:"servicedemo",component:ProductComponent},
      {path:"parenttochild",component:ParentComponent},

      {path:"Login",component:LoginComponent},

      {path:'**',component:PageNotFoundComponent}
      
  
];





@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
