import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-diven-form',
  templateUrl: './template-diven-form.component.html',
  styleUrls: ['./template-diven-form.component.css']
})
export class TemplateDivenFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
AddUser(form){
  console.log(form.value);
}
}
