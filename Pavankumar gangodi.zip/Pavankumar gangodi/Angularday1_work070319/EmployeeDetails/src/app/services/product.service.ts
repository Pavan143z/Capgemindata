import { Injectable } from '@angular/core';
import { Product } from '../model/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  [x: string]: any;
  products: Product[] = [
    { id: 1, name: 'laptop', cost: 60000, category: 'electronics' },
    { id: 2, name: 'mobile', cost: 20000, category: 'electronics' },
    { id: 3, name: 'fan', cost: 5000, category: 'electronics' }
  ];
  getproducts() {
    return this.products;
  }


  addproduct(id: number, productname: string, cost: number, category: string) {
    let newproduct =
    {
      id: id,
      name: productname,
      cost: cost,
      category: category
    };
    return this.products.push(newproduct);
  }
  deleteproduct(product: Product) {
    //alert(event.name);
    let indexPosition = this.products.indexOf(product);
    return this.products.splice(indexPosition, 1);
  }
  constructor() { }
}
