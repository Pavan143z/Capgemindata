import { EmpgenderfilterPipe } from './empgenderfilter.pipe';

describe('EmpgenderfilterPipe', () => {
  it('create an instance', () => {
    const pipe = new EmpgenderfilterPipe();
    expect(pipe).toBeTruthy();
  });
});
