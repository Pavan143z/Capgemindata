import { Pipe, PipeTransform } from '@angular/core';
import { getRenderedText } from '@angular/core/src/render3';

@Pipe({
  name: 'empgenderfilter'
})
export class EmpgenderfilterPipe implements PipeTransform {

  transform(value:string,gender: string):string {
    if(gender.toLowerCase() == "male")
    return "Mr :" + value;
    else
    return "Miss:"+value;
  }
    
    
  }

