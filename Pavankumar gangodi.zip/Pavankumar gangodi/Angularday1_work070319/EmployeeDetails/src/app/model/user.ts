export class User {


    name:string;
    constact:number;
    email:string
}
