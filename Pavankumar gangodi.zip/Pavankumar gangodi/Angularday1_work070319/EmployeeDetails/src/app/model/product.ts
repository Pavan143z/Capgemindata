export class Product {
    id:number;
    name:string;
    cost:number;
    category:string;
}
