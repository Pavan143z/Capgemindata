import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product';



@Component({
  selector: 'app-assignment',
  templateUrl: './assignment.component.html',
  styleUrls: ['./assignment.component.css']
})
export class AssignmentComponent implements OnInit {
 

  constructor() { }
  Duration:number=30;
    title = "Subjects"
    subject: string[] = ["Angular","MongoDB","Express"]
  title1="ShowFaculty"


    ShowFaculty: boolean = true;
    Faculty: string = "Rashmi Pawaskar";

    isValid:boolean=true;
  
  //Object
  pro:Product={
    id:11,
    name:"Note9",
    cost:43828,
    category:'Electronics'};

    //Array
    products:Product[]=[
      {id:11,name:"Note9",cost:43828,category:'Electronics'},
      {id:12,name:"Keyboard",cost:900,category:'Electronics'},

      {id:13,name:"Chair",cost:1200,category:'Furniture'},
    ];

  

  ngOnInit() {
  }

}
