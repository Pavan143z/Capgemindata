import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Employee Details';
  firstName:string='Rashmi';
  lastName:string='Awaskar';
  address:string='Mumbai';
  salary:number=60000;
}
