import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmpComponent } from './emp/emp.component';
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { AssignmentComponent } from './assignment/assignment.component';
import { EmpgenderfilterPipe } from './empgenderfilter.pipe';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { PageComponent } from './page/page.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { EventComponent } from './event/event.component';
import { TemplateDivenFormComponent } from './template-diven-form/template-diven-form.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { LoginComponent } from './login/login.component';
import { ProductComponent } from './product/product.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
@NgModule({
  declarations: [
    AppComponent,
    EmpComponent,
    EmployeelistComponent,
    AssignmentComponent,
    EmpgenderfilterPipe,
    ContactComponent,
    HomeComponent,
    AboutComponent,
    NavBarComponent,
    PageComponent,
    PageNotFoundComponent,
    EventComponent,
    TemplateDivenFormComponent,
    ReactiveFormComponent,
    LoginComponent,
    ProductComponent,
    ParentComponent,
    ChildComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
 
    AppRoutingModule,
  
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
