import { Injectable } from '@angular/core';
//import { HttpClient } from 'selenium-webdriver/http';
import { HttpClient } from '@angular/common/http';
import { User } from '../model/user';


@Injectable({
  providedIn: 'root'
})
export class UserService {
 
  
  baseurl:string="http://localhost:3000/users";

  constructor(private http:HttpClient) { }



  // //Modift User
  // updateUser(user:User){
  //   return this.http.put(this.baseurl+'/'+user.id,user);
  // }





getusers()
{
  return this.http.get<User[]>(this.baseurl);
}

deleteUser(id:number){
  return this.http.delete(this.baseurl+"/"+id)
}

getUsersById(id: number): any {
  return this.http.get<User>(this.baseurl+"/"+id);
}
updateUser(user: User){
  return this.http.put(this.baseurl+"/"+user.id,user);
}
//Add User
createuser(user:User){
  console.log(user.firstName)
  return this.http.post(this.baseurl,user);
}

}