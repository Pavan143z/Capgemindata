import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormGroup, FormBuilder,Validators, ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './login/login.component';
import { ListUserComponent } from './component/list-user/list-user.component';
import { HttpClientModule } from '@angular/common/http';
import { AddUserComponent } from './component/add-user/add-user.component';
import { EdituserComponent } from './component/edit-user/edit-user.component';
import { CarouselModule } from 'ngx-bootstrap/carousel';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    ListUserComponent,
    AddUserComponent,
    EdituserComponent
  ],
  imports: [

    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    CarouselModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
