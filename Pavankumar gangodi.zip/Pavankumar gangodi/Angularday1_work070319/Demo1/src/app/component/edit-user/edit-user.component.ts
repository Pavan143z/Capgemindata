import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
@Component({
    selector: 'app-edituser',
    templateUrl: './edit-user.component.html',
    styleUrls: ['./edit-user.component.css']
})
export class EdituserComponent
    implements OnInit {
    editForm: FormGroup;
    submitted: boolean = false;
    constructor(private router: Router,
        private userService: UserService, private formBuilder: FormBuilder) { }
    ngOnInit() {
        if (localStorage.getItem("username") != null) {
            let userId = localStorage.getItem("enterUserId");
            if (!userId) {
                alert('Invalid Action');
                this.router.navigate(['\list-user']);
                return;
            }
            this.editForm =
                this.formBuilder.group({
                    id: [],
                    firstname: ['', Validators.required],
                    lastname: ['', Validators.required],
                    email: ['', Validators.required]
                });
            this.userService.getUsersById(+userId).subscribe(data => {
                this.editForm.setValue(data)
            });
        }
    }
    onSubmit() {
        this.submitted = true;
        if (this.editForm.invalid) {
            return;
        }
        this.userService.updateUser(this.editForm.value).subscribe(data => {
            this.router.navigate(['/list-user']);
        },
            error => {
                alert('error');
            })
    }
}