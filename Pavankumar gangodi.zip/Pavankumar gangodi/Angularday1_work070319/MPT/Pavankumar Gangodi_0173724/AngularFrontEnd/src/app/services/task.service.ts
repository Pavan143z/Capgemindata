import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { New } from '../model/new';
import { User } from '../model/user';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  baseurl:string="http://localhost:3000/users"
  userurl:string="http://localhost:3000/users"
  constructor( private http:HttpClient) { }
  getTask(){
    return this.http.get<New[]>(this.baseurl);
  }
  getUser(){
    return this.http.get<New[]>(this.userurl);
  }
  //delete user by id
  deleteTask(id:number){
    return this.http.delete(this.baseurl + "/" +id)
  }
  addTask(task:New){
    return this.http.post(this.baseurl,task);
  }
  addUser(user:New){
    return this.http.post(this.userurl,user);
  }
  // Get users by id
  gettaskById(id :number){
    return this.http.get<User>(this.baseurl+"/" +id)
  }
  editTask(task:New){
    return  this.http.put<New>(this.baseurl+"/" +task.id, task);
  }
}


