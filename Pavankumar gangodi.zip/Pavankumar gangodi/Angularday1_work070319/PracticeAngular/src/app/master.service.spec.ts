import { MasterService } from "./master.service";
import { ValueService } from "./value.service";
describe('MasterService Testing',()=>{
let masterservice :MasterService;
//Testing of real Service value
it('Should return Hello World from another service',()=>{
  masterservice= new MasterService(new ValueService);
  expect(masterservice.getValue()).toBe("Hello World");
  })
});
