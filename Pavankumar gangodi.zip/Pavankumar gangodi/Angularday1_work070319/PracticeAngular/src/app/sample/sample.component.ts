import { Component, OnInit } from '@angular/core';
  @Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css']
   })
  export class SampleComponent implements OnInit {
  data:string ="Hello My name is pavan"
  isToggle:boolean=false;
  onToggle(){
  this.isToggle=!this.isToggle;
  console.log('hello' +this.isToggle);
  } 
  constructor() { }
  ngOnInit() {
  }}
  