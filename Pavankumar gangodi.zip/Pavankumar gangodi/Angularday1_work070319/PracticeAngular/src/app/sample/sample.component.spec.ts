import {async, ComponentFixture, TestBed } from '@angular/core/testing';
  import { SampleComponent } from './sample.component';
  describe('SampleComponent', ()=> {
  let component: SampleComponent;
  let fixture: ComponentFixture<SampleComponent>;
  beforeEach(async(()=> {
  TestBed.configureTestingModule({
  declarations: [ SampleComponent ]
  })
  .compileComponents();
  }));
  beforeEach(() => {
  fixture = TestBed.createComponent(SampleComponent);
  component = fixture.componentInstance;
  fixture.detectChanges();
  });
  it('should create', ()=> {
  expect(component).toBeTruthy();
  });
  it('onToggle the Button click it should be true',()=>{
  expect(component.isToggle).toBe(false,'Fasle at first');
  component.onToggle();
  expect(component.isToggle).toBe(true,'After click it should be true');
   component.onToggle();
   expect(component.isToggle).toBe(false,'After second click');
  });

  });