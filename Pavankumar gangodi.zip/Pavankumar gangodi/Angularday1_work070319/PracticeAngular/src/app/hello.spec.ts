import { helloWorld } from "./hello";

describe('helloWorld',()=>
{
    it('says hello',()=>
    {
        expect(helloWorld()).toEqual('Hello World');
    }
    );
}
);