import { Component, Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent  {
stringinterpolation="pavan";
numberinterpolation=4558

myname:string="Pavan";
myFun()
{
  alert("Hi i am button click event");
}
myName:string=" ";

count : number = 0;   
@Output() counterChange :  EventEmitter<number>;
   constructor(){
       this.counterChange = new EventEmitter();
   }
@Input() 
   get counter(){
       return this.count; 
   }
   increment(){
       this.count = this.count+1; 
       this.counterChange.emit(this.count);
   }
   decrement(){
       this.count = this.count - 1; 
       this.counterChange.emit(this.count);
   }
}


