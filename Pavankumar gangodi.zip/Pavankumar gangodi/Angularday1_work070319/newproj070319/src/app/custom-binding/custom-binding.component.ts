import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-custom-binding',
  template:`
      {{result}}
      `,
      styles:[]
  })
export class CustomBindingComponent {

  constructor() { }

 @Input() result:number=100; 
  }


