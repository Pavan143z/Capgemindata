import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'newprojectday2';
  private switch = true;
  private lists=["Pavan","Anu","Prabhas"];
  private value=200;
  onSwitch(){
    this.switch =! this.switch
  }
}
