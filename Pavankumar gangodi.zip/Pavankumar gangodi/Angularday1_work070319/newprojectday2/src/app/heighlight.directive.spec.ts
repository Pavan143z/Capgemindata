import { HeighlightDirective } from './heighlight.directive';

describe('HeighlightDirective', () => {
  it('should create an instance', () => {
    const directive = new HeighlightDirective();
    expect(directive).toBeTruthy();
  });
});
