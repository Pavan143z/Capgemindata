import { Injectable } from '@angular/core';

import { ToDo } from '../model/todo';
// import { HttpClient } from 'selenium-webdriver/http';
import{HttpClient}from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class ServiceTodoService {

  baseUrl = "http://localhost:3000/todo"
  constructor(private http:HttpClient) { }



  getTodo() {
    return this.http.get<ToDo[]>(this.baseUrl )
  }
  deletetoJson(id) {
    return this.http.delete(this.baseUrl + "/" + id)
  }

  addtoJson(todo: ToDo) {

    return this.http.post(this.baseUrl, todo)

  }
  edittojson(todo: ToDo) {
    console.log(todo.id)
    return this.http.put<ToDo[]>(this.baseUrl + "/" + todo.id, todo)
  }

  gettodoById(id: number) {
    return this.http.get<ToDo>(this.baseUrl + "/" + id)
  }
}








