import { TestBed } from '@angular/core/testing';

import { ServiceTodoService } from './servicetodo.service';

describe('ServicetodoService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ServiceTodoService = TestBed.get(ServiceTodoService);
    expect(service).toBeTruthy();
  });
});
