export class ToDo{
    id:number;
    todoName:string;
    status:string
}