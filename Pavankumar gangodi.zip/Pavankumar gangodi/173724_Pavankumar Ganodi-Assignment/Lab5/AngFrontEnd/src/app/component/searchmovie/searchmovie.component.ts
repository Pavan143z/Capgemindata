import { Component, OnInit } from '@angular/core';
import { Movie } from 'src/app/model/Movie';
import { Router } from '@angular/router';
import { MoviesService } from 'src/app/Services/movies.service';


@Component({
  selector: 'app-searchmovie',
  templateUrl: './searchmovie.component.html',
  styleUrls: ['./searchmovie.component.css']
})
export class SearchmovieComponent implements OnInit {
  moviesArray
  dgenre: string;
  constructor(private router: Router, private movieservice: MoviesService) { }
  ngOnInit() {
  }
  showMovie(frm): void {
    this.dgenre=frm.value.dgenre
    console.log(this.dgenre)
    this.movieservice.getmoviesdata(this.dgenre).subscribe(data => { this.moviesArray = data
      console.log(this.moviesArray)})
 
      

  }
}
