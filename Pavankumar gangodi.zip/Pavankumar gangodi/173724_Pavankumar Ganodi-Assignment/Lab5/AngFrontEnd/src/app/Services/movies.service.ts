import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Movie } from '../model/Movie';
@Injectable({
  providedIn: 'root'
})
export class MoviesService {
  baseUrl: string= "http://localhost:3000/api/movie";
  
  constructor(private http:HttpClient) { }
   getmovies()
   {
     return this.http.get<Movie[]>(this.baseUrl+"/");
   }
   getmoviesdata(dgenre)
   {
     return this.http.get<Movie[]>(this.baseUrl+"/"+dgenre);
   }


  getMoviesById(id:number)
  {
    return this.http.get(this.baseUrl+"/"+id);
  }

  
  createMovie(movie: Movie)
   {
    return this.http.post(this.baseUrl,movie);
   }
}


