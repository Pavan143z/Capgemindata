var mongodb = require('mongodb');

var mongoclient1 = mongodb.MongoClient;

var url = 'mongodb://localhost:27017/employee';

//connect to mongoclient
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err);
    }
    else {
        console.log("connection established" + url);

        //creating database
        var db = client.db('employee');

        //creating  collection
        var collection = db.collection('employeescol');

        var employees = [
            {
              "empId": 1001,
              "empName": "Jack",
              "empSalary": 40000,
              "empAddress": {
                "city": "Pune",
                "state": "Maharashtra"
              }
            },
            {
              "empId": 1002,
              "empName": "Jill",
              "empSalary": 42000,
              "empAddress": {
                "city": "Nashik",
                "state": "Maharashtra"
              }
            },
            {
              "empId": 1003,
              "empName": "Sebastian",
              "empSalary": 14000,
              "empAddress": {
                "city": "Agra",
                "state": "Uttar Pradesh"
              }
            },
            {
              "empId": 1004,
              "empName": "Jessica",
              "empSalary": 30000,
              "empAddress": {
                "city": "Lucknow",
                "state": "Uttar Pradesh"
              }
            },
            {
              "empId": 1005,
              "empName": "Terena",
              "empSalary": 45000,
              "empAddress": {
                  "city": "San Diego",
                  "state": "California"
                }
              },
             {
                "empId": 1006,
                "empName": "Aadel",
                "empSalary": 50000,
                "empAddress": {
                  "city": "San Jose",
                  "state": "California"
                }
              }
            ]


        //find all mobile
        collection.find({"empAddress.state":"California"}).toArray(function (err, res) {
            if (err) {
                console.log(err);
            }
            else {
                console.log('data is  ', res);
            }
        });
    }
});