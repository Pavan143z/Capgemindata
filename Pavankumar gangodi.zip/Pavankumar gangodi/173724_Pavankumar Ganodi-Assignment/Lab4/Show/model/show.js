var mong=require('mongoose');


const showSchema=new mong.Schema({

    showName:{
        type:Number,
        required:false
    },
    location:{
        type:String,    
        required:false
    },
    date:{
        type:Date,
        required:false
    },
    price:{
        type:Number,
        required:false
    },
    availableSeats:{
        type:Number,
        required:false
    },
    book:{
        type:String,
        required:false
    }
});

const shows=module.exports=mong.model('shows',showSchema)